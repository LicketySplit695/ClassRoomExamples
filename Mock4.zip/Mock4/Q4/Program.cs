using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    class Program
    {
        static void Main(string[] args)
        {
            List<Item> itemList = new List<Item>();
            Console.WriteLine("Enter the number of items:");
            int noOfItems = Convert.ToInt32(Console.ReadLine());
            for(int i = 0 ; i < noOfItems ; i++) {
                String itemDetails = Console.ReadLine();
                String []splited = itemDetails.Split(',');
                itemList.Add(new Item(Convert.ToInt64(splited[0]), splited[1], Convert.ToDouble(splited[2]), Convert.ToInt32(splited[3])));
            }
            Console.WriteLine("1.Store\n2.Online\nEnter the choice:");
            int choice = Convert.ToInt32(Console.ReadLine());
            if (choice == 1)
            {
                Console.WriteLine("Total amount:{0:0.00}",Item.CalculateTotalBill(itemList));
            }
            if (choice == 2)
            {
                Console.WriteLine("1.One day delivery\n2.Normal delivery\nEnter delivery type:");
                int delivery_type = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Total amount:{0:0.00}", Item.CalculateTotalBill(itemList,delivery_type));
            }
        }
    }
