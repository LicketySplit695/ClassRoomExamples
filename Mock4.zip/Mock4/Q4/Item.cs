using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Item
{
    long _id;
    public long Id
    {
        get { return _id; }
        set { _id = value; }
    }

    string _name;
    public string Name
    {
        get { return _name; }
        set { _name = value; }
    }

    double _cost;
    public double Cost
    {
        get { return _cost; }
        set { _cost = value; }
    }

    int _quantity;
    public int Quantity
    {
        get { return _quantity; }
        set { _quantity = value; }
    }

    public Item()
    { }

    public Item(long _id, string _name, double _cost, int _quantity)
    {
        Id = _id;
        Name = _name;
        Cost = _cost;
        Quantity = _quantity;
    }


    public static double CalculateTotalBill(List<Item> itemList) 
	{
        double total_amount = 0.0;
        foreach (Item i in itemList)
        {
            total_amount += i.Cost * i.Quantity;
        }
        return total_amount;
	}

    public static double CalculateTotalBill(List<Item> itemList, int deliveryType)
	{
        if (deliveryType == 1)
        {
            return CalculateTotalBill(itemList) * 1.15;
        }
        else if (deliveryType == 2)
        {
            return CalculateTotalBill(itemList) * 1.08;
        }
        else
        {
            return 0.0;
        }
    }
}
