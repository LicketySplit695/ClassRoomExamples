using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Item
{
    long _id;

    public long Id
    {
        get { return _id; }
        set { _id = value; }
    }
    string _name;

    public string Name
    {
        get { return _name; }
        set { _name = value; }
    }
    string _itemCode;

    public string ItemCode
    {
        get { return _itemCode; }
        set { _itemCode = value; }
    }
    double _cost;

    public double Cost
    {
        get { return _cost; }
        set { _cost = value; }
    }

    public Item(long _id, string _name, string _itemCode, double _cost)
    {
        Id = _id;
        Name = _name;
        ItemCode = _itemCode;
        Cost = _cost;
    }

    public override string ToString()
    {
        return String.Format("{0} {1,10} {2,15} {3,15:0.0}", Id, Name, ItemCode, Cost);
    }

    public override bool Equals(object obj)
    {
        return this.Name.ToUpper()==((Item)obj).Name.ToUpper() && this.ItemCode==((Item)obj).ItemCode;
    }

    public override int GetHashCode()
    {
        return this.Name.GetHashCode()+this.ItemCode.GetHashCode();
    }
}

