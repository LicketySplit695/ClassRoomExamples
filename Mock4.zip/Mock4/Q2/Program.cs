﻿using System;
using System.Text.RegularExpressions;

public class Program {

    public static void Main(string[] args) 
    {
        string couponCode;
        Console.WriteLine("Enter the coupon code:");
        couponCode = Console.ReadLine();
        Console.WriteLine("1.Validate coupon code\n2.Check validity of coupon code\nEnter the choice:");
        //fill the code
        int n = int.Parse(Console.ReadLine());
        switch (n)
        {
            case 1:
                if (ValidateCouponCode(couponCode))
                {
                    Console.WriteLine("Coupon code validated");
                }
                else
                {
                    if (!Regex.IsMatch(couponCode.Substring(2, 2), "^[0-9]{2}$"))
                    {
                        Console.WriteLine("Input string was not in the correct format");
                    }
                    Console.WriteLine("Coupon code is invalid");
                }
                break;
            case 2:
                Console.WriteLine("Enter the bought date:");
                DateTime dt = DateTime.ParseExact(Console.ReadLine(), "dd-MM-yyyy", null);
                if (CheckValidityOfCouponCode(couponCode, dt)) Console.WriteLine("Coupon code is valid");
                else Console.WriteLine("The validity of coupon code is over");
                break;
        }
    }
    
   
 public static bool ValidateCouponCode(string couponCode) {
 
       //fill the code
        string pattern = "^[A-Za-z]{1}[A-Za-z0-9]{1}[0-9]{2}[A-Za-z0-9]{5}[A-Za-z]{1}$";
        return Regex.IsMatch(couponCode, pattern);
    }
    
  
  public static bool CheckValidityOfCouponCode(string couponCode, DateTime boughtDate) {
        //fill the code
        string days = couponCode.Substring(2, 2);
        DateTime validDate = boughtDate.AddDays(double.Parse(days));
        int val = DateTime.Compare(validDate, DateTime.ParseExact("01-01-2018","dd-MM-yyyy",null));
        bool res = val > 0 ? true : false;
        return res;        
    }    
}
