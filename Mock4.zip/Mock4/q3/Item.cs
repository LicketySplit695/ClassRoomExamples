using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Item
{
    long _id;

    public long Id
    {
        get { return _id; }
        set { _id = value; }
    }
    string _name;

    public string Name
    {
        get { return _name; }
        set { _name = value; }
    }
    string _itemCode;

    public string ItemCode
    {
        get { return _itemCode; }
        set { _itemCode = value; }
    }
    double _cost;

    public double Cost
    {
        get { return _cost; }
        set { _cost = value; }
    }
    public Item()
    {}
    public Item(long _id, string _name, string _itemCode, double _cost)
    {
        this._id = _id;
        this._name = _name;
        this._itemCode = _itemCode;
        this._cost = _cost;
    }
    public override string ToString()
    {
        return String.Format("{0} {1,15} {2,15:0.0}",Name,ItemCode,Cost);
    }
    public static Item CreateItem(string itemDetail)
    {
        string[] s = itemDetail.Split(',');
        Item item = new Item(long.Parse(s[0]), s[1], s[2], double.Parse(s[3]));
        return item;
    }
    public static Item SearchItemByName(string itemName, List<Item> itemList)
    {
        foreach (Item i in itemList)
        {
            if (i.Name.Equals(itemName))
                return i;
        }
        return null;
    }
    public static List<Item> FindAllItemByPriceRange(List<Item> itemList, double minRate, double maxRate)
    {
        List<Item> s = new List<Item>();
        foreach (Item i in itemList)
        {
            if (i.Cost >= minRate && i.Cost <= maxRate)
                s.Add(i);
        }
        return s;
    }
}