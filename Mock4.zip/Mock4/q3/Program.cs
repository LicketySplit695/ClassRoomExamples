﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q3
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Item> list = new List<Item>();
            int ch=0;
            do
            {
                Console.WriteLine("1. Add items\n2. Search item by name\n3. Get item between price range\n4. Exit\nEnter your choice:");
                 ch = int.Parse(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        Console.WriteLine("Enter the number of items:");
                        int c = int.Parse(Console.ReadLine());
                        for (int i = 0; i < c; i++)
                        {
                            string s = Console.ReadLine();
                            list.Add(Item.CreateItem(s));
                        }
                        break;
                    case 2:
                        Console.WriteLine("Enter the name:");
                        string name = Console.ReadLine();
                        if(Item.SearchItemByName(name, list)==null)
                            Console.WriteLine("Item "+name+" not found");
                        else
                        {
                            Item search = Item.SearchItemByName(name, list);
                            Console.WriteLine("Item Detail\nItem name: " + search.Name + "\nItem code: " + search.ItemCode + "\nItem Cost: {0:0.0}" , search.Cost);
                        }
                        break;
                    case 3:
                        Console.WriteLine("Enter the max and min cost:");
                        double min = double.Parse(Console.ReadLine());
                        double max = double.Parse(Console.ReadLine());
                        List<Item> pr = Item.FindAllItemByPriceRange(list, min, max);
                        Console.WriteLine("{0} {1,15} {2,15}", "Name", "Code", "Cost");
                        if (pr.Capacity > 0)
                        {
                            foreach (Item i in pr)
                                Console.WriteLine(i);
                        }
                        break;
                }
            } while (ch != 4);
        }
    }
}
