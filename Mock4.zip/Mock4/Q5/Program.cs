﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q5 {
    class Program {
        static void Main(string[] args) {
            Console.WriteLine("Enter the number of purchase:");
            int count = Convert.ToInt32(Console.ReadLine());

            List<Purchase> purchaseList = new List<Purchase>();

            Console.WriteLine("Enter the purchase details:");
            for (int i=0;i<count;i++) {
                try {
                    Purchase caughtObject = Purchase.ObtainPurchaseWithAmount(Console.ReadLine());
                    purchaseList.Add(caughtObject);
                    Console.WriteLine("Purchase " + caughtObject.Id + " is added to the list");
                }
                catch (InvalidWholeSaleException e) {
                    Console.WriteLine(e.GetType() + ": " + e.Message);
                }
            }

            purchaseList.Sort();

            Console.WriteLine("Whole sale purchases:");
            Console.WriteLine("{0} {1,10} {2,15}", "ID", "User", "Amount");
            foreach (var iterator in purchaseList) {
                Console.WriteLine(iterator);
            }
        }
    }
}
