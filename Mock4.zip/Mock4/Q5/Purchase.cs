﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Purchase : IComparable<Purchase> {
    long _id;
    DateTime _purchaseDate;
    double _totalAmount;
    string _user;

    public Purchase() {}

    public Purchase(long _id, DateTime _purchaseDate, double _totalAmount, string _user) {
        Id = _id;
        PurchaseDate = _purchaseDate;
        TotalAmount = _totalAmount;
        User = _user;
    }

    public static Purchase ObtainPurchaseWithAmount(String str) {
        if (str.Split(',').Length < 18) {
            throw new InvalidWholeSaleException("Purchase " + str.Split(',')[0] + " is not a whole sale");
        }

        double totalAmount = 0.0;
        for (int i=4;i<str.Split(',').Length;i+=3) {
            totalAmount += Convert.ToDouble(str.Split(',')[i]) * Convert.ToInt32(str.Split(',')[i + 1]);
        }

        return new Purchase(Convert.ToInt64(str.Split(',')[0]), DateTime.ParseExact(str.Split(',')[1], "dd-MM-yyyy", null), totalAmount, str.Split(',')[2]);
    }

    public long Id {
        get { return _id; }
        set { _id = value; }
    }
    public DateTime PurchaseDate {
        get { return _purchaseDate; }
        set { _purchaseDate = value; }
    }
    public double TotalAmount {
        get { return _totalAmount; }
        set { _totalAmount = value; }
    }
    public string User {
        get { return _user; }
        set { _user = value; }
    }

    public override string ToString() {
        return string.Format("{0} {1,10} {2,15}", Id, User, TotalAmount);
    }

    public int CompareTo(Purchase other) {
        return this.TotalAmount.CompareTo(other.TotalAmount);
    }
}