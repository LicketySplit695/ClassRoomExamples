﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program {
    public static void Main(string[] args) {
        Console.WriteLine("Enter the number of purchase:");
        int count = Convert.ToInt32(Console.ReadLine());
        SortedDictionary<string, int> dictionary = new SortedDictionary<string, int>();

        for (int i=0;i<count;i++) {
            Purchase.ObtainPurchaseWithItem(dictionary, Console.ReadLine());
        }

        Console.WriteLine("{0} {1,15}", "Item name", "Quantity");
        foreach (var iterator in dictionary) {
            Console.WriteLine("{0} {1,15}", iterator.Key, iterator.Value);
        }
    }
}