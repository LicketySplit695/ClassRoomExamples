﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Purchase {
    long _id;
    DateTime _purchaseDate;
    double _totalAmount;
    string _user;

    public Purchase() {}

    public Purchase(long _id, DateTime _purchaseDate, double _totalAmount, string _user) {
        Id = _id;
        PurchaseDate = _purchaseDate;
        TotalAmount = _totalAmount;
        User = _user;
    }

    public static void ObtainPurchaseWithItem(SortedDictionary<string, int> dictionary, String str) {
        for (int i=3;i<str.Split(',').Length;i+=3) {
            string key = str.Split(',')[i];

            if (dictionary.ContainsKey(key)) {
                dictionary[key] += Convert.ToInt32(str.Split(',')[i + 2]);
            }
            else {
                dictionary.Add(key, Convert.ToInt32(str.Split(',')[i + 2]));
            }
        }
    }

    public long Id {
        get { return _id; }
        set { _id = value; }
    }
    public DateTime PurchaseDate {
        get { return _purchaseDate; }
        set { _purchaseDate = value; }
    }
    public double TotalAmount {
        get { return _totalAmount; }
        set { _totalAmount = value; }
    }
    public string User {
        get { return _user; }
        set { _user = value; }
    }
}