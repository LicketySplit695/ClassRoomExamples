﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the value of n");
            int n = int.Parse(Console.ReadLine());
            List<UserProgram> l = new List<UserProgram>();
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Enter batch name");
                string bname = Console.ReadLine();
                Console.WriteLine("Enter number of students passed");
                int stu = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter exam name");
                string exam = Console.ReadLine();
                l.Add(new UserProgram(bname, stu, exam));
            }

            IEnumerable<IGrouping<string, UserProgram>> a = from x in l
                    group x by x.Batch_name;                    
                    
            foreach (IGrouping<string,UserProgram> b in a)
            {
                Console.WriteLine("{Batch = "+b.Key+"}");
                foreach (UserProgram c in b)
                {
                    Console.WriteLine(c.Exam_name+" "+c.Students_passed);
                }
            }
        }
    }

    class UserProgram
    {
        string _batch_name;
        int _students_passed;
        string _exam_name;

        public string Batch_name
        {
            get { return this._batch_name; }
            set { this._batch_name = value; }
        }
        public int Students_passed
        {
            get { return this._students_passed; }
            set { this._students_passed = value; }
        }
        public string Exam_name
        {
            get { return this._exam_name; }
            set { this._exam_name = value; }
        }

        public UserProgram(string _batch_name,int _students_passed,string _exam_name)
        {
            this._batch_name = _batch_name;
            this._students_passed = _students_passed;
            this._exam_name = _exam_name;
        }
    }
}
