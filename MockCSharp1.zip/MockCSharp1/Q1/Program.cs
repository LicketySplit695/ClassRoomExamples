﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//namespace Q1
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.WriteLine("Enter gift 1 detail:");
//            string s1 = Console.ReadLine();
//            string[] s11 = s1.Split(',');
//            Gift g1 = new Gift(Convert.ToInt64(s11[0]), s11[1], s11[2], Convert.ToDouble(s11[3]));
//            Console.WriteLine("Enter gift 2 detail:");
//            string s2 = Console.ReadLine();
//            string[] s22 = s2.Split(',');
//            Gift g2 = new Gift(Convert.ToInt64(s22[0]), s22[1], s22[2], Convert.ToDouble(s22[3]));

//            Console.WriteLine("Gift 1:");
//            Console.WriteLine("{0} {1,10} {2,15} {3,15}", "ID", "Name", "Gift_Code", "Cost");
//            Console.WriteLine(g1);
//            Console.WriteLine("Gift 2:");
//            Console.WriteLine("{0} {1,10} {2,15} {3,15}", "ID", "Name", "Gift_Code", "Cost");
//            Console.WriteLine(g2);

//            if (g1.Equals(g2))
//            {
//                Console.WriteLine("Gift 1 is same as Gift 2");
//            }
//            else
//            {
//                Console.WriteLine("Gift 1 and Gift 2 are different");
//            }
//        }
//    }

//    class Gift
//    {
//        long _id;
//        string _name;
//        string _giftCode;
//        double _cost;

//        public long Id
//        {
//            get { return this._id; }
//            set { this._id = value; }
//        }
//        public string Name
//        {
//            get { return this._name; }
//            set { this._name = value; }
//        }
//        public string GiftCode
//        {
//            get { return this._giftCode; }
//            set { this._giftCode = value; }
//        }
//        public double Cost
//        {
//            get { return this._cost; }
//            set { this._cost = value; }
//        }

//        public Gift()
//        {
//        }
//        public Gift(long _id, string _name, string _giftCode, double _cost)
//        {
//            this._id = _id;
//            this._name = _name;
//            this._giftCode = _giftCode;
//            this._cost = _cost;
//        }


//        public override string ToString()
//        {
//            return string.Format("{0} {1,10} {2,15} {3,15:0.0}", Id,Name,GiftCode,Cost);
//        }
//        public override bool Equals(object obj)
//        {
//            if (obj == null)
//            {
//                return false;
//            }
//            if (!(obj is Gift))
//            {
//                return false;
//            }
//            return this._name.ToUpper().Equals(((Gift)obj)._name.ToUpper()) && this._giftCode.ToUpper().Equals(((Gift)obj)._giftCode.ToUpper());
//        }
//        public override int GetHashCode()
//        {
//            return this._name.GetHashCode() ^ this._giftCode.GetHashCode();
//        }
//    }
//}

namespace Q1
{
    class Gift
    {
        public long _id {get; set;}
        public string _name {get; set;}
        public string _giftCode {get;set;}
        public double _cost {get; set;}

        public Gift(long _id, string _name, string _giftCode, double _cost)
        {
            this._id = _id;
            this._name = _name;
            this._giftCode = _giftCode;
            this._cost = _cost;
        }

        public override string ToString()
        {
            return String.Format("{0} {1,10} {2,15} {3,15}", _id, _name, _giftCode, _cost);
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;
            else if (!(obj is Gift))
                return false;
            else
                return this._name.ToUpper().Equals(((Gift)obj)._name.ToUpper()) && this._giftCode.ToUpper().Equals(((Gift)obj)._giftCode.ToUpper());
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }

    class Program
    {
        static void Main()
        {
            Gift obj1, obj2;
            Console.WriteLine("Enter gift 1 detail:");
            string[] arr = Console.ReadLine().Split(',');
            obj1 = new Gift(long.Parse(arr[0]), arr[1], arr[2], double.Parse(arr[3]));

            Console.WriteLine("Enter gift 2 detail:");
            string[] arr1 = Console.ReadLine().Split(',');
            obj2 = new Gift(long.Parse(arr1[0]), arr1[1], arr1[2], double.Parse(arr1[3]));

            
            Console.WriteLine("Gift 1:");
            Console.WriteLine("{0} {1,10} {2,15} {3,15}", "ID", "Name", "GiftCode", "Cost");
            Console.WriteLine(obj1);

            Console.WriteLine("Gift 2:");
            Console.WriteLine("{0} {1,10} {2,15} {3,15}", "ID", "Name", "GiftCode", "Cost");
            Console.WriteLine(obj2);

            if(obj1.Equals(obj2))
                Console.WriteLine("Gift 1 is same as Gift 2");
            else
                Console.WriteLine("Gift 1 and Gift 2 are different");
        }
    }
}
