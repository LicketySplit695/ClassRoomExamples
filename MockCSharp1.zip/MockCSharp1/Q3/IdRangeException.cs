﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    class IdRangeException : Exception
    {
        string msg;
        public IdRangeException()
        {
        }
        public IdRangeException(string msg)
        {
            this.msg = msg;
        }

        public override string ToString()
        {
            return "IdRangeException: "+msg;
        }
    }
}
