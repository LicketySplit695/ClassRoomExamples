﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    class Program
    {
        static void Main()
        {
            bool flagOuter = true;
            bool flagInner = true;
            int ID = 0;
            string stream = "";
            while (flagOuter)
            {
                if (flagInner)
                {
                    Console.WriteLine("Enter the id of the Trainee");
                    flagInner = false;
                }
                else
                    Console.WriteLine("Please enter the id again");
                try
                {
                    ID = int.Parse(Console.ReadLine());
                    if (ID > 99999 || ID < 10000)
                        throw new IdRangeException("Id not within range");
                    flagOuter = false;
                }
                catch (IdRangeException e)
                {
                    Console.WriteLine(e);
                }
                catch (FormatException e)
                {
                    Console.WriteLine(e.Message);
                }
            }

            Console.WriteLine("Enter the name of the Trainee");
            string name = Console.ReadLine();

            flagOuter = true;
            flagInner = true;

            while (flagOuter)
            {
                if (flagInner)
                {
                    Console.WriteLine("Enter the stream of the Trainee");
                    flagInner = false;
                }
                else
                    Console.WriteLine("Please enter the stream again");
                try
                {
                    stream = Console.ReadLine();
                    if (!(stream == "Java" || stream == "CSharp" || stream == "Mainframes"))
                        throw new InvalidStreamException("An invalid stream");
                    flagOuter = false;
                }
                catch (InvalidStreamException e)
                {
                    Console.WriteLine(e);
                }
            }

            Console.WriteLine("Enter the number of batches alloted");
            int number = int.Parse(Console.ReadLine());

            Trainee obj = new Trainee(ID,name,stream,number);

            Console.WriteLine("The Trainee details are");
            Console.WriteLine(obj);
        }
    }
}
