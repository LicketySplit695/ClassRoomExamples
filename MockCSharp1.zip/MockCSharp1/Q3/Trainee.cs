﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    class Trainee
    {
        public int _id {get; set;}
        public string _name {get; set;}
        public string _stream {get; set;}
        public int _noOfBatches { get; set; }

        public Trainee(int id, string name, string stream, int noofbatches)
        {
            _id = id;
            _name = name;
            _stream = stream;
            _noOfBatches = noofbatches;
        }

        public override string ToString()
        {
            return String.Format("{0} {1} {2} {3}",_id,_name,_stream,_noOfBatches);
        }

    }
}
