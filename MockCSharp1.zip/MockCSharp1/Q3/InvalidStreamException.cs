﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    class InvalidStreamException : Exception
    {
        string msg;
        public InvalidStreamException()
        {
        }
        public InvalidStreamException(string msg)
        {
            this.msg = msg;
        }
        public override string ToString()
        {
            return "InvalidStreamException: " + msg;
        }
    }
}
