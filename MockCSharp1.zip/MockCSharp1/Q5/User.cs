﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q5
{
    class User
    {
        public string name { get; set; }
        public int ComplaintCount { get; set; }

        public User(string name, int ComplaintCount)
        {
            this.name = name;
            this.ComplaintCount = ComplaintCount;
        }

        public override string ToString()
        {
            return "User name : " + name + "\nComplaint Count : " + ComplaintCount;
        }
    }
}
