﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q5
{
    class Program
    {
        static void Main(string[] args)
        {
            string flag = "no";
            Dictionary<string, User> complaintDictionary = new Dictionary<string, User>();
            do
            {
                Console.WriteLine("Enter the user name");
                string userName = Console.ReadLine();
                Console.WriteLine("Enter Complaints - seperated by \"|\" symbol");
                string Complaints = Console.ReadLine();
                int count = Complaints.Split('|').Length;
                
                User obj = new User(userName, count);
                complaintDictionary.Add(userName, obj);
                Console.WriteLine("Do you want to add another user (yes/no)");
                flag = Console.ReadLine();
            } while (flag.Equals("yes"));

            do
            {
                Console.WriteLine("Enter the user name to search");
                string search = Console.ReadLine();

                if (complaintDictionary.ContainsKey(search))
                    Console.WriteLine(complaintDictionary[search]);
                else
                    Console.WriteLine("No user found with the name {0}", search);
                Console.WriteLine("Do you want to search another user (yes/no)");
                flag = Console.ReadLine();
            } while (flag.Equals("yes"));
        }
    }
}
