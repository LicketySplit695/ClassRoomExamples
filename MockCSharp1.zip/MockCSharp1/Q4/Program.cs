﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number of ISLes");
            int n = int.Parse(Console.ReadLine());

            ISL[] IslList = new ISL[n];
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Enter ISL {0} details",(i+1));
                Console.WriteLine("Enter the ISL date");
                string date = Console.ReadLine();
                Console.WriteLine("Enter the team one");
                string teamone = Console.ReadLine();
                Console.WriteLine("Enter the team two");
                string teamtwo = Console.ReadLine();
                Console.WriteLine("Enter the Venue");
                string venue = Console.ReadLine();

                IslList[i] = new ISL(date, teamone, teamtwo, venue);
            }

            ISLBO islbobj = new ISLBO();

            islbobj.DisplayAllISLDetails(IslList);

            Console.WriteLine("Enter the date to be searched");
            string search = Console.ReadLine();

            islbobj.DisplaySpecificISLDetails(IslList, search);

        }
    }
}
