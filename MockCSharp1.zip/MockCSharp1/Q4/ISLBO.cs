﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q4
{
    class ISLBO
    {
        public void DisplayAllISLDetails(ISL[] ISLList)
        {
            Console.WriteLine("ISL Details");
            Console.WriteLine("{0,-35}{1,-30}{2,-15}{3}", "TeamOne", "TeamTwo", "Date", "Venue");
            foreach (ISL x in ISLList)
                Console.WriteLine(x);
        }
        public void DisplaySpecificISLDetails(ISL[] ISLList, String date)
        {
            Console.WriteLine("ISL Details");
            Console.WriteLine("{0,-35}{1,-30}{2,-15}{3}", "TeamOne", "TeamTwo", "Date", "Venue");
            foreach (ISL x in ISLList)
            {
                if(x._date.Equals(date))
                    Console.WriteLine(x);
            }
        }
    }
}
