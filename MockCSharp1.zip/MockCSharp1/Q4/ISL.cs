﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q4
{
    class ISL
    {
        public string _date {get; set;}
        public string _teamone {get; set;}
        public string _teamtwo {get; set;}
        public string _venue {get; set;}

        public ISL(string a, string b, string c, string d)
        {
            _date = a;
            _teamone = b;
            _teamtwo = c;
            _venue = d;
        }

        public override string ToString()
        {
            return String.Format("{0,-35}{1,-30}{2,-15}{3}",_teamone,_teamtwo,_date,_venue);
        }
    }
}
