﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Delete : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"server = PC189957\MSSQLSERVER2008; database = CRM1; integrated security = true");
    SqlCommand cmd;
    int a;

    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        string str = "delete from Registration where Username = '" + Username.Text + "' and Password = '" + Password.Text + "'";
        cmd = new SqlCommand(str, con);
        a = cmd.ExecuteNonQuery();
        if (a > 0)
            Response.Write("Data deleted Successfully");
        con.Close();
    }
}