﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Registration : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"server = PC189957\MSSQLSERVER2008; database = CRM1; integrated security = true");
    SqlCommand cmd;
    int a;

    protected void Submit_Click(object sender, EventArgs e)
    {
        con.Open();
        string str = "insert into Registration values('" + Username.Text + "','" + Password.Text + "','" + Email.Text + "','" + Securityquestion.Text + "','" + Answer.Text +"'," + Phone.Text + ")";
        cmd = new SqlCommand(str, con);
        //Response.Write("Hello");

        a = cmd.ExecuteNonQuery();
        if (a > 0)
            Response.Write("Registration Successfull");
        con.Close();
    }
}