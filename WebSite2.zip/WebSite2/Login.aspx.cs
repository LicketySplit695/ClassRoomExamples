﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Login : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"server = PC189957\MSSQLSERVER2008; database = CRM1; integrated security = true");
    SqlDataReader dr;
    SqlCommand cmd;
    
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Submit_Click(object sender, EventArgs e)
    {
        //string str = "select Username, Password from Registration where Username = '" + Username.Text + "' and password = '" + Password.Text + "'";
        string str = "select Username, Password from Registration where Username = @user and password = @pass";
        cmd = new SqlCommand(str, con);
        cmd.Parameters.AddWithValue("@user", Username.Text);
        cmd.Parameters.AddWithValue("@pass", Password.Text);
        con.Open();
        dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            Session["S"] = dr[0]; //Default time = 20minutes
            Session.Timeout = 1;
            Response.Redirect("Inbox.aspx");
        }
        else
            Response.Write("Invalid username/Password");
        con.Close();
    }
}