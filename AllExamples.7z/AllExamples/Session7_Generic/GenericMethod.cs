﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session7_Generic
{
    class GenericMethod
    {
        static void Main()
        {
            GenericMethod Gm = new GenericMethod();
            int a = 100;
            int b = 200;
            Gm.swap<int>(ref a,ref  b);
            Console.WriteLine(a + " " + b);

        }
        void swap<T>(ref T lhs, ref T rhs)
        {
            T tem;
            tem = lhs;
            lhs = rhs;
            rhs = tem;
        }
    }
}
