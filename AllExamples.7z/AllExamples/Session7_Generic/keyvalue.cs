﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session7_Generic
{
    class keyvalue
    {
        static void Main(string[] args)
        {
            Dictionary<int, string> dic = new Dictionary<int, string>();
            dic.Add(1, "apple");

            foreach (KeyValuePair<int, string> pair in dic)
            {
                Console.WriteLine("{0}, {1}", pair.Key, pair.Value);
            }

            Dictionary<int, string> dic1 = new Dictionary<int, string>();
            dic.Add(1, "apple");

            foreach (KeyValuePair<int, string> pair in dic1)
            {
                if (pair.Value == "apple")
                {
                    Console.WriteLine("{0}", pair.Key);
                }
            }

            Dictionary<int, string> dic2 = new Dictionary<int, string>();
            dic2.Add(1, "apple");
            dic2.Add(2, "orange");
            int myValue = dic2.FirstOrDefault(x => x.Value == "orange").Key;
        }
    }
}
