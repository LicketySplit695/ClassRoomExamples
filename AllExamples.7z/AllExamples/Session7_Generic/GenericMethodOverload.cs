﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session7_Generic
{
    class GenericMethodOverload
    {
        static void Main()
        {
            OverLoadMehod ge = new OverLoadMehod();
            int r=1000;
            int r1=9000;
            ge.add<int>(r, r1);
        }
    }
    class OverLoadMehod
    {
        internal void  add()
        {

        }
        internal void add<T>(T a,T b)
        {         
            int i = (int)Convert.ChangeType(a, typeof(int));
            int j = (int)Convert.ChangeType(b, typeof(int));
            Console.WriteLine(i+j);
        }    
        internal void Add<T, U>()
        {

        }
    }
}
