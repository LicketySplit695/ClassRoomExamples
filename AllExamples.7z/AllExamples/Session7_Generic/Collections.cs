﻿using System;
using System.Collections;

namespace Session7_Generic
{
    class Collections
    {
        static void Main(string[] args)
        {
            ArrayList ab = new ArrayList();
                

            ArrayList ar = new ArrayList();
            ar.Add(new Employee1 { Emp_id = 1, Emp_name = "raj", emp_salary = 14355 });
            ar.Add(new Employee1 { Emp_id = 2, Emp_name = "rajee", emp_salary = 12344 });
            ar.Add(new Employee1 { Emp_id = 3, Emp_name = "subham", emp_salary = 12333 });
            ar.Add(new Employee1 { Emp_id = 4, Emp_name = "pradeep", emp_salary = 222123 });
            foreach (Employee1 e in ar)
            {
                if (e.emp_salary > 13000)
                {
                    Console.WriteLine(e.Emp_name);
                }
            }
            Employee2 ab2 = new Employee2();
            ab2.Add();
            ab2.Print();
            

        }
    }
    class Employee1
    {
        public int Emp_id { get; set; }
        public string Emp_name { get; set; }
       public int emp_salary{get;set; }

    }
    class Employee2
    {
        public int Emp_id { get; set; }
        public string Emp_name { get; set; }
        public int emp_salary { get; set; }
        ArrayList ar = new ArrayList();
        public void Add()
        {
            
            ar.Add(new Employee2 { Emp_id = 1, Emp_name = "raj", emp_salary = 14355 });
            ar.Add(new Employee2 { Emp_id = 2, Emp_name = "rajee", emp_salary = 12344 });
            ar.Add(new Employee2 { Emp_id = 3, Emp_name = "subham", emp_salary = 12333 });
            ar.Add(new Employee2 { Emp_id = 4, Emp_name = "pradeep", emp_salary = 222123 });
        }
        public void Print()
        {
            foreach (Employee2 e in ar)
            {
                if (e.emp_salary > 13000)
                {
                    Console.WriteLine(e.Emp_name);
                }
            }
        }

    }
}
