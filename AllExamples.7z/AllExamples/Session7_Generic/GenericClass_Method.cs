﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session7_Generic
{
    class GenericClass_Method
    {
        static void Main(string[] args)
        {
        }
    }
}
