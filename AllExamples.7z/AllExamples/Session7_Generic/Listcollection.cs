﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session7_Generic
{
    class Listcollection
    {
        static void Main(string[] args)
        {
            List<string> ar = new List<string>();
            ar.Add("raj");
            ar.Add("rajee");
            ar.Add("subham");
            ar.Insert(2, "rr");
            foreach (string i in ar)
                Console.WriteLine(i);
            
        }
    }
}
