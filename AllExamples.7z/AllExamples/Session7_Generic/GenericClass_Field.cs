﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session7_Generic
{
    class GenericClass_Field
    {
       

        static void Main()
        {
            GenericClass_Field1<int> ar = new GenericClass_Field1<int>();
            ar.Field = 1000;
            int total = ar.Field + 1000;
            Console.WriteLine(total);
            GenericClass_Field1<string> ar1 = new GenericClass_Field1<string>();
            ar1.Field = "raj";
            string s = ar1.Field + "Kumar";
            Console.WriteLine(s);
        }
    }
    class GenericClass_Field1<T>
    {
      internal   T Field;
    }
}
