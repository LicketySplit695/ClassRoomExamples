﻿using System;

namespace Session7_Generic
{
    class GenericClass_methods
    {
        static void Main(string[] args)
        {
            Team<int, string> ab = new Team<int, string>();
            ab.ss(33, "rr");
        }
    }
    class Team<T, U>
    {
        public void ss(T a,U b)
    {
        int r=(int)Convert.ChangeType(a,typeof(int));
        string  r1 = (string )Convert.ChangeType(b, typeof(string ));
        string w = r + r1;
        Console.WriteLine(w);

    }
    }
}
