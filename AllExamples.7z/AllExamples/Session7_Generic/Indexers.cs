﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session7_Generic
{
    class Indexers
    {
        public static void Main()
        {
            AB ob = new AB();
           Console.WriteLine( ob[1]);
           
           ob[1] = "raj1";
           Console.WriteLine(ob[1]);
        }
    }
    class AB
    {
        /*
        
        int[] ar = { 44, 22, 55 };
        internal int this[int i]
        {
            get
            {
              return  ar[i];
            }
            set
            {
                if (value == 0)
                {
                    throw new Exception("not pass 0 value");
                }
                ar[i] = value;
            }
        }
         */
        string[] name = { "raj", "rajee", "suni" };
        internal string  this[int i]
        {
            get
            {
                return   name [i];
            }
            set
            {
                if (value == "raj")
                {
                    throw new Exception("not pass 0 value");
                }
                name[i] = value;
            }
        }
    }
}
