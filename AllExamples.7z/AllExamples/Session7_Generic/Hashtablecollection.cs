﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace Session7_Generic
{
    class Hashtablecollection
    {
        static void Main(string[] args)
        {
            Dictionary<int, string> emp = new Dictionary<int, string>();
            emp.Add(1, "raj");
            emp.Add(2, "rajee");
            emp.Add(3, "raj kumar");
            emp.Add(4, "Ram");
            if (emp.ContainsKey(1))
            {
                Console.WriteLine(emp[1]);
            }

            Hashtable ht = new Hashtable();
            ht.Add(1, "rr");
            ht.Add(2, "ram");
            if (ht.ContainsValue("rr"))
            {

                Console.WriteLine(ht[1]);
            }
          
        }
    }
}
