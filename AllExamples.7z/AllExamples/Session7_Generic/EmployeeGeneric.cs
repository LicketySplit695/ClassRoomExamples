﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session7_Generic
{
    class EmployeeGeneric
    {     List<Employee> Em;
        public void AddEmployee()
        {
            Em = new List<Employee>();
            Em.Add(new Employee { EmpName = "raj", EmpNumber = 33, Empsalary = 34444 });
            Em.Add(new Employee { EmpName = "rajee", EmpNumber = 331, Empsalary = 3444 });
            Em.Add(new Employee { EmpName = "raj kumar", EmpNumber = 332, Empsalary = 134444 });
                
        }
        public void Print()
        {  foreach (var i in Em)
            {
                if (i.Empsalary > 20000)
                {
                    Console.WriteLine(i.EmpName);
                }
            }
        }
        static void Main(string[] args)
        {
            EmployeeGeneric ab = new EmployeeGeneric();
            ab.AddEmployee();
            ab.Print();
        }
    }
    class Employee
    {
        internal int EmpNumber { get; set; }
        internal string EmpName { get; set; }
        internal double Empsalary { get; set; }
      
    }
}
