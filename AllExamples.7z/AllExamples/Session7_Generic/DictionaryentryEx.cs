﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session7_Generic
{
    class DictionaryentryEx
    {
        static void Main()
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            dic.Add("txt", "notepad.exe");
            dic.Add("bmp", "paint.exe");
            dic.Add("rtf", "wordpad.exe");
            Console.WriteLine(dic["txt"]);
            dic["rtf"] = "winword.exe";
            Console.WriteLine(dic["rtf"]);
            string value = "";
            if (dic.TryGetValue("rtf", out value))
            {
                Console.WriteLine("For key = \"rtf\", value = {0}.", value);
            }
            else
            {
                Console.WriteLine("Key = \"rtf\" is not found.");
            }
            if (!dic.ContainsKey("ht"))
            {
                dic.Add("ht", "hypertrm.exe");
            }
            Console.WriteLine();
            foreach (KeyValuePair<string, string> kvp in dic)
            {
                Console.WriteLine("Key = {0}, Value = {1}",
                    kvp.Key, kvp.Value);
            }
            // To get the values alone, use the Values property.
            Dictionary<string, string>.ValueCollection valueColl =
                dic.Values;

            // The elements of the ValueCollection are strongly typed
            // with the type that was specified for dictionary values.
            Console.WriteLine();
            foreach (string s in valueColl)
            {
                Console.WriteLine("Value = {0}", s);
            }

            // To get the keys alone, use the Keys property.
            Dictionary<string, string>.KeyCollection keyColl =
                dic.Keys;

            // The elements of the KeyCollection are strongly typed
            // with the type that was specified for dictionary keys.
            Console.WriteLine();
            foreach (string s in keyColl)
            {
                Console.WriteLine("Key = {0}", s);
            }
            // Use the Remove method to remove a key/value pair.
            Console.WriteLine("\nRemove(\"doc\")");
            dic.Remove("doc");

            if (!dic.ContainsKey("doc"))
            {
                Console.WriteLine("Key \"doc\" is not found.");
            }


        }
    }
}
