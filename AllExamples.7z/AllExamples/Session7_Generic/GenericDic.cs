﻿using System;
using System.Collections.Generic;
using System.Collections;

namespace CollectionEx
{
    class GenericDic
    {
        static void Main(string[] args)
        {
            Employee5 e = new Employee5();
            e.AddCollection();
            e.Print();

        }
    }
    class Employee5
    {
        public int Emp_id { get; set; }
        public string Emp_name { get; set; }
        public int Emp_salary { get; set; }
        ArrayList ar = new ArrayList();
        Dictionary<int, Employee5> ab;
        public void AddCollection()
        {
            ab = new Dictionary<int, Employee5>();

            ab.Add(1, new Employee5 { Emp_id = 1, Emp_name = "ram", Emp_salary = 9000 });
            ab.Add(2, new Employee5 { Emp_id = 2, Emp_name = "raj kumar", Emp_salary = 19000 });
            ab.Add(3, new Employee5 { Emp_id = 3, Emp_name = "subham", Emp_salary = 93000 });
        }
        public void Print()
        {
            foreach (KeyValuePair<int, Employee5> e in ab)
            {
                if (e.Key == 1)
                {
                    Console.WriteLine(e.Value.Emp_name);
                }
            }
        }
    }
}
