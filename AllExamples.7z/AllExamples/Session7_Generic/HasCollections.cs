﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Session7_Generic
{
    class HasCollections
    {
        static void Main(string[] args)
        {
            Hashtable ab = new Hashtable();
            ab.Add(1, "raj");
            ab.Add(2,"ss");

            foreach (DictionaryEntry di in ab)
            {
                if (Convert.ToInt32(di.Key) == 1)
                {
                    Console.WriteLine(di.Value);
                }
            }


            
        }
    }
}
