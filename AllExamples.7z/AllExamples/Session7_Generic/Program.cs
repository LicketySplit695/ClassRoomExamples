﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session7_Generic
{
    class HotelReservation 
    {
        List<ReservationStatus> rs;
        internal List<ReservationStatus> show()
        {
            rs = new List<ReservationStatus>();
            rs.Add(new ReservationStatus() { CustomerFirstname = "raj", CustomerLastname = "kumar" });
            rs.Add(new ReservationStatus() { CustomerFirstname = "rajee", CustomerLastname = "kumar1" });
            return rs;
        }
        internal void PrintReservationList()
        {
            
            List<ReservationStatus> R = show();
            foreach (var i in R)
            {
               
                Console.WriteLine("Firstname \t Lastname");
                Console.WriteLine("{0} \t \t {1}", i.CustomerFirstname, i.CustomerLastname);
            }

        }
            
        static void Main(string[] args)
        {
           List< ReservationStatus> rs = new List<ReservationStatus> ();
           rs.Add(new ReservationStatus(){CustomerFirstname="raj",CustomerLastname="kumar"});
           rs.Add(new ReservationStatus() { CustomerFirstname = "rajee", CustomerLastname = "kumar1" });
           foreach (ReservationStatus i in rs)
           {
               Console.WriteLine("Firstname \t Lastname");
               Console.WriteLine("{0} \t \t {1}", i.CustomerFirstname, i.CustomerLastname);
           }
           HotelReservation hr = new HotelReservation();
           hr.PrintReservationList();
       
        }
    }
    class ReservationStatus
    {
       
        internal string CustomerFirstname { get; set; }
        internal string CustomerLastname { get; set; }
        internal int RoomNumber { get; set; }
        internal DateTime CheckInDate { get; set; }
        internal DateTime CheckOutDate { get; set; }
        internal int BillNumber { get; set; }
        internal double  BillAmount { get; set; }
        internal double BillPaid { get; set; }

       
    }
}
