﻿using System;

namespace ClassObject2
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = "rajkumarsharma";
            int a = s.IndexOf('k');
            Console.WriteLine(a);
            int b = s.LastIndexOf('m');

            /*
            Console.WriteLine("Enter number of Teams");
            int a =int.Parse( Console.ReadLine());
            Team[] t = new Team[a];
            for (int i = 0; i < t.Length; i++)
            {
                Console.WriteLine("Enter team Details" + (i + 1));
                string s = Console.ReadLine();
                string[] ar = s.Split(',');
                t[i] = new Team(ar[0], ar[1]);
            }
            for (int i = 0; i < t.Length; i++)
            {
                Console.WriteLine
                  ("Team name:{0} \n Runs:{1}", t[i].Name, t[i].Runs);
            }
             */
        }
    }
}
