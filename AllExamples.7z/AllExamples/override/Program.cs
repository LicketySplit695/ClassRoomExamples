﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace @override
{
    class Program
    {
        static void Main(string[] args)
        {
            C.SM();
            B b = new C();
            b.NIM();
            b.VIM();
        }
    }
    class B
    {
        public static void SM() { Console.WriteLine("Hello from B.SM()"); }
        public virtual void VIM() { Console.WriteLine("Hello from B.VIM()"); }
        public void NIM() { Console.WriteLine("Hello from B.NIM()"); }
    }
    class C : B
    {
        public override void VIM()
        {
        Console.WriteLine("Hello from C.VIM()");   
        }
    }
}
