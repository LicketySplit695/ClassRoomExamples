﻿using System;
namespace Class_Object
{
    class Program
    {
        static void Main(string[] args)
        {
            SavingAccount saveacc = new SavingAccount("rajee", 123, 1000, 0.02);
            Console.WriteLine("Interest Rate Monthly="+saveacc.InterestRateMonthly());
            Checkin chek = new Checkin("raj", 12345, 9000, 100);
           Console.WriteLine("Balance="+ chek.checkbalance());
            Console.ReadLine();
        }
    }
    class Account
    {
      public   int account_number;
      public   string account_holder_name;
        public double account_balance;
        public int account_fee;
        public int GetAccountNumber()
        {
            return account_number;
        }
        public void SetAccountNumber(int accno)
        {
            account_number = accno;

        }
    }
    class SavingAccount : Account
    {
        double interestRate;
        public SavingAccount(string name, int acc_no, double balance, double rate)
        {
            account_balance = balance;
            interestRate = rate;
        }
        public double InterestRateMonthly()
        {
            return account_balance = account_balance * interestRate;
        }
    }
    class Checkin : Account
    {
        double transfees;
        public Checkin(string name, int acc_no, int amount, double fees)
        {
            account_balance = amount;
            transfees = fees;
        }
        public double checkbalance()
        {
            return account_balance - transfees;
        }
    }

}
