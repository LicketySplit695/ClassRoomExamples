﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Team
    {
        string _name;
        Player player;
        public Team(string _name, Player _player)
        {
            this._name = _name;
            this.player = _player;
        }
        public string Name { get; set; }
        public Player Player1 { get; set; }

    }

