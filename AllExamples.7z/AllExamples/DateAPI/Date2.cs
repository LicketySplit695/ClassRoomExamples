﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DateAPI
{
    class Date2
    {
        static void Main(string[] args)
        {
            DateTime date = DateTime.Today;
            int day = date.Day;
            int month = date.Month;
            int year = date.Year;
            string strDate = day.ToString() + "/" + month.ToString() + "/" + year.ToString();
            Console.WriteLine(strDate);
        }
    }
}
