﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class PlayerBO
    {
        public Player CreatePlayer(string data)
        {
            string[] str = data.Split(',');
            Player ob = new Player(str[0], str[1], str[2]);
            return ob;

        }
    }
