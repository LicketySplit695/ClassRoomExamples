﻿using System;


    class Program
    {
        static void Main(string[] args)
        {

            // string[] formats = { "M/d/yyyy", "d/M/yyyy", "M-d-yyyy", "d-M-yyyy", "d-MMM-yy", "d-MMMM-yyyy", };

            DateTime date = DateTime.Today;
            Console.WriteLine(date);
            string strDate = String.Format("{0:MM/dd/yyyy}", date);
            Console.WriteLine(strDate );
            string strDate1 = String.Format("{0:dd/MM/yyyy}", date);
            Console.WriteLine(strDate1);
            string strDate2 = String.Format("{0:yyyy/MM/dd}", date);
            Console.WriteLine(strDate2);
            string s = "1 May 2018";
            string strDate3 = String.Format("{0:MM/dd/yyyy}", s);
            Console.WriteLine(strDate3);

           
        }
    }

