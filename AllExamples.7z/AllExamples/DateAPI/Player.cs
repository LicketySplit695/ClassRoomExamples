﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Player
    {
        string _name;
        string _country;
        string _skill;
        public Player(string _name, string _country, string _skill)
        {
            this._name = _name;
            this._country = _country;
            this._skill = _skill;
        }
        public string Name { get; set; }

        public string Country { get; set; }
        public string Skill { get; set; }

    }

