﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

  
        class TeamBO
        {
            public Team CreateTeam(string data, Player PlayerList)
            {
                string[] s = data.Split(',');

                Team t = new Team(s[0], PlayerList);
                return t;
            }
        }
    

