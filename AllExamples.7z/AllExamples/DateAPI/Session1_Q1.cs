﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DateAPI
{
    class Session1_Q1
    {
        static void Main(string[] args)
        {

            DateTime dt = DateTime.Now;
            Console.WriteLine(dt);
            Console.WriteLine(dt.AddYears(2));
            string ss = "12/12/2017";
            DateTime dt1 = DateTime.Parse(ss);
            Console.WriteLine(dt1.ToString("MMMM yyyy dd"));
            String s = null;
            string[] arr = dt1.GetDateTimeFormats();
            foreach (string sss in arr) {
                Console.WriteLine(sss);
            }
            //nsole.WriteLine(dt1.GetDateTimeFormats());
            int a;
            int.TryParse(s, out a);
           
           // string date = "1 May 2-17";
            /*DateTime date = DateTime.Now;
            string s = date.ToString("dd-MM-yy");
            Console.WriteLine(s );//27/01/2018
            DateTime date1 = DateTime.Now;
            string s1 = date1.ToString("MM/dd/yy");
            Console.WriteLine(s1);
            string q = "1 May 2011";
           
           DateTime a= DateTime.Parse(q);
           Console.WriteLine("Date"+a);//5/1/2011
           Console.WriteLine("Date" + a.ToString("dd/MM/yyyy"));//01/05/2011
           Console.WriteLine("Date" + a.ToString("yyyy/MM/dd"));//2011/05/01   
           DateTime m = DateTime.Now;
            Console.WriteLine(   m.AddYears(2));*/




        }
    }
}
