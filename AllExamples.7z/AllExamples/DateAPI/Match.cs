﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Match
    {
        String _date;
        String _teamone;
        String _teamtwo;
        String _venue;
        Team team;

        public Match(string _date, string _teamone, string _teamtwo, string   _venue,Team team)
        {
            this._date = _date;
            this._teamone = _teamone;
            this._teamtwo = _teamtwo;
            this._venue = _venue;
            this.team = team;

        }
        public override string ToString()
        {
            return string.Format("{0,-15} {1,-15} {2,-15} {3,-15}");
        }

    }

