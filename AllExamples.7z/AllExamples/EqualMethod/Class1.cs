﻿using System;
namespace EqualMethod
{
    class Class1
    {
        static void Main(string[] args)
        {
            Pro p = new Pro();
            p.name = "raj";
            Pro p1 = new Pro();
            p1.name = "raj";
            Console.WriteLine("output");
            Console.WriteLine(p == p1);
            Console.WriteLine(p.Equals(p1));
        }
    }
    class Pro
    {   public string name { get; set; }
        
        
        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;
            if (!(obj is Pro))
                return false;
            return this.name == ((Pro)obj).name;
                
        }
        public override int GetHashCode()
        {
            return this.name .GetHashCode();
        }
  
        
    }
}
