﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EqualMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int a = 10;
            int b = 10;
            Console.WriteLine(a == b);//T
            Console.WriteLine(a.Equals(b));//T
            
         /*   
            Product p1=new Product{ Price=101,Name="rr"};
            Product p2 = p1;
            p2.Name = "rr";
            p2.Price = 101;
            Console.WriteLine(p1 == p2);//True
            Console.WriteLine(p1.Equals(p2));//true
          */  
            
            Product p1 = new Product();
            p1.Name = "raj";
            p1.Price = 101;
            Product p2 = new Product();
            p2.Name = "raj1";
            p2.Price = 101;
            Console.WriteLine(p1 == p2);//false ref qual is false  p1 and p1 have diff ref that's why is false
            Console.WriteLine(p1.Equals(p2));// false but why value qual is false --its does'nt make sence 
            //that why we override equal method  
            //if u not create equal method to override p1.equal(p2)) is false if u create then true becouse its compare the value is equal or not
         

        }
    }
    class Product
    {
        public int Price { get; set; }
        public string Name { get; set; }

        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;
            if (!(obj is Product))
                return false;
            return this.Name == ((Product)obj).Name 
                && this.Price == ((Product)obj).Price;
        }
    }
}
