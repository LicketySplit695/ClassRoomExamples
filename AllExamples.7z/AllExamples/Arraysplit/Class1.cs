﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions ;
using System.Threading.Tasks;

namespace Arraysplit
{
    class Class1
    {
        public static void Main()
        {
            String input = "abacus -- alabaster - * - atrium -+- " +
                           "any -*- actual - + - armoir - - alarm";
            String pattern = @"\s-\s?[+*]?\s?-\s";
            String[] elements = Regex.Split(input, pattern);
            foreach (var element in elements)
                Console.WriteLine(element);
        }
    }
}
