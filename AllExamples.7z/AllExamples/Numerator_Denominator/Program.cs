﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Numerator_Denominator
{
    class Program
    {
        static void Main(string[] args)
        {
            Fraction fr = new Fraction(1,2);
            Console.WriteLine(fr);
            try
            {
                Fraction fr1 = new Fraction(2, 0);
                Console.WriteLine(fr1);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
    class Fraction
    {
        int numerator;
        int denominator;
        /// <summary>

        /// Initialize the fraction properties

        /// </summary>

        /// <param name="numerator">Upper number</param>

        /// <param name="denominator">Lower number</param>
        public Fraction(int numerator, int denominator)
        {
            this.Numerator = numerator;
            this.Denominator = denominator;
        }
        public int Numerator
        {
            get
        {
            return this. numerator;
        }
            set
            {
               this. numerator = value;

            }
        }
        public int Denominator
        {
            get
            {
                return this.denominator;
            }
            set
            {
                if (value == 0)
                {
                    throw new Exception(" 0 denominator");
                }
                this.denominator  = value;

            }
        }
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(this.Numerator + "/" + this.Numerator);
            sb.Append("or");
            sb.Append(this.Numerator / this.Denominator);
            return sb.ToString();

        }
    }
}
