﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondLargest
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] i = new int[] { 4, 8, 1, 9, 2, 7, 3 }; 
            Array.Sort(i);
            foreach (int r in i)
                Console.WriteLine(r);
            Console.WriteLine("Highest number :" + i[i.Length - 1]);
            Console.WriteLine("Second highest number :" + i[i.Length - 2]); 
            Console.WriteLine("Lowest number :" + i[i.Length - i.Length]);
            Console.WriteLine("Second Lowest number :" + i[i.Length - i.Length + 1]); 
        }
    }
}
