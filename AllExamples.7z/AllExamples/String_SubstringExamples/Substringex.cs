﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace String_SubstringExamples
{
    class Substringex
    {
        static void Main(string[] args)
        {
            String s = "aaaaabbbcccccccdd";
            Char charRange = 'b';
            int startIndex = s.IndexOf(charRange);
            Console.WriteLine("Start Index="+startIndex);
            int endIndex = s.LastIndexOf(charRange);
            Console.WriteLine("Last Index=" + endIndex );
            int length = endIndex - startIndex + 1;
       string r=     s.Substring(startIndex, length);
       Console.WriteLine(r);

            Console.WriteLine("{0}.Substring({1}, {2}) = {3}",
                              s, startIndex, length,
                              s.Substring(startIndex, length));
        }
    }
}
