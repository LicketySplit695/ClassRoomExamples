﻿using System;
namespace String_SubstringExamples
{
    class StringIndex
    {
        static void Main(string[] args)
        {
            string Name = "rajkumarsharma";
            int a = Name.IndexOf('j');//ans 2 match char
            Console.WriteLine(a);
          int b=  Name.IndexOf("k");//3 match string
          Console.WriteLine(b);
          int c = Name.IndexOf('s', 7);

          Console.WriteLine(c);
          Console.WriteLine("-------");
          int d = Name.IndexOf('w', 5,5);// -1 ans 
          Console.WriteLine(d);

        }
    }
}
