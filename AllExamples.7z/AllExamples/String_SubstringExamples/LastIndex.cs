﻿using System;

namespace String_SubstringExamples
{
    class LastIndex
    {
        static void Main(string[] args)
        {
            string Name = "rajkumarsharma";
            int r = Name.LastIndexOf('a');
            Console.WriteLine(r);
           int r1 = Name.LastIndexOf('m',5);
           Console.WriteLine(r1);
           
        }
    }
}
