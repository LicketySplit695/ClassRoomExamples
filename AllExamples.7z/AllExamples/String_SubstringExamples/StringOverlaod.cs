﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace String_SubstringExamples
{
    class StringOverlaod
    {
        static void Main(string[] args)
        {
            Person per = new Person();
            per.Name = "raj";
            per.Age = 20;
            Console.WriteLine("Name {0} Age {1} ", per.Name, per.Age);
            Person ob1 = new Person { Name = "subham", Age = 299 };
            Console.WriteLine(ob1);
        }
    }
    class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }

        public override string ToString()
        {
            return "Person " + Name + " " + Age;
        }

    }
}
