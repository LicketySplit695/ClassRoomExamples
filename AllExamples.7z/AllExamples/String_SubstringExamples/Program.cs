﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace String_SubstringExamples
{
    class Program
    {
        static void Main(string[] args)
        {
            //string Functions
            string Name="raj kumar sharma";
            //Split the name by space
            string[] s = Name.Split(' ');
            foreach (string i in s)
                  Console.WriteLine(i);
            Console.WriteLine("=================");
            foreach (string i in s)
            {
                if (i.Contains("raj"))
                {
                    Console.WriteLine(i);
                }
            }

            
            



        }
    }
}
