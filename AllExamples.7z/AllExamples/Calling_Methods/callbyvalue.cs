﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calling_Methods
{
    class callbyvalue
    {
        static void Main(string[] args)
        {
            int r = 1000;
            int r1 = 9000;
            Callbyvalues call = new Callbyvalues();
            call.ss(ref r,ref r1);
            Console.WriteLine("Resultr=" + r);
            Console.WriteLine("Resultr1=" + r1);
        }
    }
    class Callbyvalues
    {
        internal void ss(ref int x,ref int y)
        {
            int tem = x;
            x = y;
            y = tem;
            //x = x + 1000;
            //y = y + 9000;
        }
    }
}
