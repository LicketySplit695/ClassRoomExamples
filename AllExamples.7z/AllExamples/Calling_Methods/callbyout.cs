﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calling_Methods
{
    class callbyout
    {
        static void Main(string[] args)
        {
            int r ;
            int r1 = 9000;
            AB.callbyout(out  r, ref r1);
            Console.WriteLine("Result of R=" + r);

        }
    }
    class AB
    {
        internal static void callbyout(out  int x,ref  int y)
        {
            x =y+9000;
        }
    }
}
