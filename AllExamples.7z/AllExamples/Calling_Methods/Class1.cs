﻿using System;


namespace Calling_Methods
{
    class A
    {
       internal  class B
        {
            internal int add(int x, int y)
            {
                return x + y;
            }
        }
    }
    class Class1
    {
        static void Main(string[] args)
        {
          
            object a = "raj";
            Console.WriteLine(a.GetType());



            AB1.Registration("raj", "ss");
            AB1.Registration("raj", "ss",234234);
            AB1.Registration("raj", "ss", 234234,"raj@gmail.com");
            AB1.Registration("raj", "ss", 234234, "raj@gmail.com","cricket");


        }
    }
    class AB1
    {
        public static  void Registration(string s,params object[]reg)
        {

        }
    }
}
