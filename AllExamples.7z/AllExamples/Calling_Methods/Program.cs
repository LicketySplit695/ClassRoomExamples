﻿using System;
    class Program
    {
        static void Main(string[] args)
        {
            int? w = null;
            int[] ar = { 44, 33, 5, 66 };
            A ob = new A();
            ob.ArrayMethod(ar);
        //    ob.ArrayMethod(20);
          //  ob.ArrayMethod(2,3);    
        }
    }
    class A
    {
        internal void  ArrayMethod(int[] ar)
        {
            foreach (int i in ar)
                Console.WriteLine(i);
        }
    }

