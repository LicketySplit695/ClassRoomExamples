﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericTypeT
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
    class Test
    {
        internal static void Test1<T>(T a, T b)
        {

        }
    }
}
