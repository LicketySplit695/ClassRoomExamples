﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Property_methods
{
    class Program
    {
        static void Main(string[] args)
        {
            Account ac = new Account();
            ac.setamount(4000);
            Console.WriteLine(ac.Getamount());
            ac.GetSetamount = 4000;
            Console.WriteLine(ac.GetSetamount);
        }
    }
    class Account
    {
        int amount;
        public void  setamount(int r)
        {
            amount = r;
        }
        public int Getamount()
        {
            return amount+5000;

        }
        public int GetSetamount
        {
            get
            {
                return amount + 5000;
            }
            set
                
        {
            if (value == 0)
                throw new Exception("not assign 0 value");
            amount = value;
        }
        }
    }
}
