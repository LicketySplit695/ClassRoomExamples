﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Team
    {
        string _name;
        string _run;
        public Team()
        {
        }
        public Team(string _name, string _run)
        {
            Name = _name;
            Run = _run;
        }
        public string Name { get; set; }
        public string Run { get; set; }
        public override string ToString()
        {
            return "Name:" + Name + " " + "Run:" + Run;
        }


    }

