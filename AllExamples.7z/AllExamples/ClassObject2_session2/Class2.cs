﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassObject2_session2
{
    class Class2
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number1");
            int a = int.Parse(Console.ReadLine());
            Team[] T = new Team[2];
            for (int i = 0; i < T.Length; i++)
            {
                Console.WriteLine("Enter the Team Name and Run");
                string r = Console.ReadLine();
                string[] str = r.Split(',');
                if (str.Length == 2)
                {
                    T[i] = new Team(str[0], str[1]);
                }
                else
                    Console.WriteLine("Please enter correct format");
            }

            for (int i = 0; i < T.Length; i++)
            {
                Console.WriteLine("Name:{0}\n Run:{1}", T[i].Name, T[i].Run);
            }

        }
    }
}
