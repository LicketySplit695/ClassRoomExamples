﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the value2");
            int a =int.Parse( Console.ReadLine());
            Team[] T = new Team[a];
            for (int i = 0; i < T.Length; i++)
            {
                Console.WriteLine("Enter Team Details" + (i + 1));
                Console.WriteLine("TeamName",(i+1));
                string name = Console.ReadLine();
                Console.WriteLine("Runs" , (i + 1));
                string run = Console.ReadLine();
                T[i] = new Team(name, run);


            }
            for (int i = 0; i < T.Length; i++)
            {
                Console.WriteLine("Details");
                Console.WriteLine("Name:{0}\n Run:{1}", T[i].Name, T[i].Run);
            }

        }
    }

