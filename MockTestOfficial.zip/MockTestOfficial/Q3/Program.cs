﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        string menu = "Menu:\n 1) Valid Car registration Number\n 2) Convert Car registration Number\n "
                      + "3) Valid Driving License";
        Console.WriteLine(menu);
        Console.WriteLine("Enter choice");
        int x = Convert.ToInt32(Console.ReadLine());
        string regnum = "", input = "";
        switch (x)
        {
            case 1:
                Console.WriteLine("car registration number");
                regnum = Console.ReadLine();
                ValidateRegNum(regnum);
                break;
            case 2:
                Console.WriteLine("car registration number");
                regnum = Console.ReadLine();
                ConvertRegNum(regnum);
                break;
            case 3:
                Console.WriteLine("driving license issue date");
                input = Console.ReadLine();
                ValidateDrivingLicense(input);
                break;
        }
        Console.ReadKey();

    }

    public static void ValidateRegNum(string reg)
    {
        string pattern = "^[A-Z]{2}[-][0-9]{2}[-][A-Z]{2}[-][0-9]{4}$";
        if(Regex.IsMatch(reg, pattern))
            Console.WriteLine("{0} is Valid", reg);
        else
            Console.WriteLine("{0} is Invalid", reg);
    }

    public static void ConvertRegNum(string reg)
    {
        Regex pattern = new Regex("[^A-Za-z0-9]");
        string result =  pattern.Replace(reg, "-");
        Console.WriteLine(result);
    }

    public static void ValidateDrivingLicense(string inp)
    {
        DateTime dtNow = DateTime.ParseExact("15-06-2017","dd-MM-yyyy",null);
        DateTime dt = DateTime.ParseExact(inp, "dd-MM-yyyy", null);

        int years = ((dtNow - dt).Days)/365;

        //Console.WriteLine((dtNow - dt).Days);
        if(years <= 10)
            Console.WriteLine("{0} years old license - valid", years);
        else
            Console.WriteLine("{0} years old license - expired", years);
    }

}
