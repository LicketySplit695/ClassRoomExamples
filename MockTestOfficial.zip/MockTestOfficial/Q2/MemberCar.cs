﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class MemberCar {
    long _id;
    string _carRegistrationNumber, _carColor;
    Member _member;
    Car _car;

    public MemberCar() {}

    public MemberCar(long _id, Car _car, Member _member, string _carRegistrationNumber, string _carColor) {
        ID = _id;
        Car = _car;
        Member = _member;
        CarRegistrationNumber = _carRegistrationNumber;
        CarColor = _carColor;
    }

    public long ID {
        get { return _id; }
        set { _id = value; }
    }
    internal Member Member {
        get { return _member; }
        set { _member = value; }
    }
    internal Car Car {
        get { return _car; }
        set { _car = value; }
    }
    public string CarColor {
        get { return _carColor; }
        set { _carColor = value; }
    }
    public string CarRegistrationNumber {
        get { return _carRegistrationNumber; }
        set { _carRegistrationNumber = value; }
    }
}