﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Member
{
    long _id;

    public long Id
    {
        get { return _id; }
        set { _id = value; }
    }

    string _firstName;

    public string FirstName
    {
        get { return _firstName; }
        set { _firstName = value; }
    }

    string _lastName;

    public string LastName
    {
        get { return _lastName; }
        set { _lastName = value; }
    }

    string _email;

    public string Email
    {
        get { return _email; }
        set { _email = value; }
    }

    string _contactNumber;

    public string ContactNumber
    {
        get { return _contactNumber; }
        set { _contactNumber = value; }
    }

    string _licenseNumber;

    public string LicenseNumber
    {
        get { return _licenseNumber; }
        set { _licenseNumber = value; }
    }

    DateTime _licenseStartDate;

    public DateTime LicenseStartDate
    {
        get { return _licenseStartDate; }
        set { _licenseStartDate = value; }
    }

    DateTime _licenseExpiryDate;

    public DateTime LicenseExpiryDate
    {
        get { return _licenseExpiryDate; }
        set { _licenseExpiryDate = value; }
    }


    public Member() { }

    public Member(long _id, string _firstName, string _lastName, string _email, string _contactNumber, string _licenseNumber, DateTime _licenseStartDate, DateTime _licenseExpiryDate)
    {
        Id = _id;
        FirstName = _firstName;
        LastName = _lastName;
        Email = _email;
        ContactNumber = _contactNumber;
        LicenseNumber = _licenseNumber;
        LicenseStartDate = _licenseStartDate;
        LicenseExpiryDate = _licenseExpiryDate;
    }

    public override string ToString()
    {
        return string.Format("Name: {0} , {1}\nMember contact details: {2} , {3}", FirstName, LastName, ContactNumber, Email);
    }

    public override bool Equals(object obj)
    {
        if (obj.GetType() != this.GetType())
        {
            return false;
        }
        else if (obj == null)
        {
            return false;
        }
        else 
        { 
            Member member = (Member)obj;
            return (this.Email.Equals(member.Email) && this.ContactNumber.Equals(member.ContactNumber));
        }
    }

    public override int GetHashCode()
    {
        return this.ContactNumber.GetHashCode() + this.Email.GetHashCode();
    }
}