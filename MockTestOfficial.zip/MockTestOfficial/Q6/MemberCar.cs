﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class MemberCar {
    long _id;
    string _carRegistrationNumber, _carColor;
    Member _member;
    Car _car;

    public MemberCar() {}

    public MemberCar(string s, List<Member> memberList, List<Car> carList)
    {
        string[] input = s.Split(',');

        ID = Convert.ToInt64(input[0]);
        long _carid = Convert.ToInt64(input[1]);
        long _memberid = Convert.ToInt64(input[2]);
        CarRegistrationNumber = input[3];
        CarColor = input[4];
        
        foreach (Car i in carList)
        {
            if (i.ID == _carid)
                Car = i;
        }
        foreach (Member i in memberList)
        {
            if (i.Id == _memberid)
                Member = i;
        }

    }

    public long ID {
        get { return _id; }
        set { _id = value; }
    }
    internal Member Member {
        get { return _member; }
        set { _member = value; }
    }
    internal Car Car {
        get { return _car; }
        set { _car = value; }
    }
    public string CarColor {
        get { return _carColor; }
        set { _carColor = value; }
    }
    public string CarRegistrationNumber {
        get { return _carRegistrationNumber; }
        set { _carRegistrationNumber = value; }
    }

    public static Dictionary<string, List<MemberCar>> groupByColor(List<MemberCar> memberCarList)
    {
       IEnumerable<IGrouping<string,MemberCar>> li = memberCarList.GroupBy(o => o.CarColor);
       Dictionary<string, List<MemberCar>> output = new Dictionary<string, List<MemberCar>>();
       foreach (IGrouping<string, MemberCar> i in li)
       {
           List<MemberCar> val = i.ToList<MemberCar>();
           output.Add(i.Key, val);
       }
       return output;
    }
}