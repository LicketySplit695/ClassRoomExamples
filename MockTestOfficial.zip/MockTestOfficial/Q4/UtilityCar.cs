﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class UtilityCar : Car {
    bool _rearCoolingVents;

    public UtilityCar(long _id, string _name, bool _rearCoolingVents) : base(_id, _name) {
        RearCoolingVents = _rearCoolingVents;
    }

    public override double CalculateDriveCost(double km) {
        return 18 * km;
    }

    public bool RearCoolingVents {
        get { return _rearCoolingVents; }
        set { _rearCoolingVents = value; }
    }
}
