﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Sedan : Car {
    bool _absEnabled;
    int _bootSpace;

    public Sedan(long _id, string _name, bool _absEnabled, int _bootSpace) : base(_id, _name) {
        AbsEnabled = _absEnabled;
        BootSpace = _bootSpace;
    }

    public override double CalculateDriveCost(double km) {
        return BootSpace > 600 ? 15 * km + (0.2 * 15 * km) : 15 * km;
    }

    public int BootSpace {
        get { return _bootSpace; }
        set { _bootSpace = value; }
    }
    public bool AbsEnabled {
        get { return _absEnabled; }
        set { _absEnabled = value; }
    }
}