﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class HatchBack : Car {
    bool _powerWindowsEnabled, _automaticGear;

    public HatchBack(long _id, string _name, bool _powerWindowsEnabled, bool _automaticGear) : base(_id, _name) {
        AutomaticGear = _automaticGear;
        PowerWindowsEnabled = _powerWindowsEnabled;
    }

    public override double CalculateDriveCost(double km) {
        return AutomaticGear ? 12 * km : 10 * km;
    }

    public bool AutomaticGear {
        get { return _automaticGear; }
        set { _automaticGear = value; }
    }
    public bool PowerWindowsEnabled {
        get { return _powerWindowsEnabled; }
        set { _powerWindowsEnabled = value; }
    }
}