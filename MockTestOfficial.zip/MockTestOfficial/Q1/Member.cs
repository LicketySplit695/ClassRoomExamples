﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Member
{
    public long _id { get; set; }
    public string _firstName { get; set; }
    public string _lastName { get; set; }
    public string _email { get; set; }
    public string _contactNumber { get; set; }
    public string _licenseNumber { get; set; }
    public DateTime _licenseStartDate { get; set; }
    public DateTime _licenseExpiryDate { get; set; }

    public Member(long _id, string _firstName, string _lastName, string _email,
        string _contactNumber, string _licenseNumber, DateTime _licenseStartDate,
        DateTime _licenseExpiryDate)
    {
        this._id = _id;
        this._firstName = _firstName;
        this._lastName = _lastName;
        this._email = _email;
        this._contactNumber = _contactNumber;
        this._licenseNumber = _licenseNumber;
        this._licenseStartDate = _licenseStartDate;
        this._licenseExpiryDate = _licenseExpiryDate;
    }

    public override string ToString()
    {
 	    return "Name: " + _firstName + " , " + _lastName + "\nMember contact details: " + _contactNumber+" , " + _email;
    }

    public override bool Equals(object obj)
    {
 	    if(obj == null)
            return false;
        else if(!(obj is Member))
            return false;
        else
            return this._contactNumber.ToUpper().Equals(((Member)obj)._contactNumber.ToUpper()) && this._email.ToUpper().Equals(((Member)obj)._email.ToUpper());
    }

    public override int GetHashCode()
    {
 	    return base.GetHashCode();
    }
}

