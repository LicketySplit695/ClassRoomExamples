﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MockTestOfficial
{
    class Member
    {
        _id

_firstName

 
_lastName

 
_email

 
_contactNumber

 
_license Number

 
_licenseStartDate

 
_licenseExpiryDate
 

    }
}
