﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

class Member : IComparable {
    long _id;
    string _firstName, _lastName, _email, _contactNumber, _licenseNumber;
    string _licenseStartDate, _licenseExpiryDate;

    public Member() {}

    public Member(long _id, string _firstName, string _lastName, string _email, string _contactNumber, string _licenseNumber, string _licenseStartDate, string _licenseExpiryDate) {
        Id = _id;
        FirstName = _firstName;
        LastName = _lastName;
        Email = _email;
        ContactNumber = _contactNumber;
        LicenseNumber = _licenseNumber;
        LicenseStartDate = _licenseStartDate;
        LicenseExpiryDate = _licenseExpiryDate;
    }

    public static Member CreateInstance(string input) {
        string pattern = "^[A-Za-z0-9.]{0,}[@]{1}[A-Za-z0-9]{0,}[.comrg]{4}$";

        string email = input.Split(',')[3];

        if (!(Regex.IsMatch(email, pattern) && (email.Substring(email.Length - 4, 4).Equals(".com") || email.Substring(email.Length - 4, 4).Equals(".org"))))
        {
            throw new InvalidEmailException("Invalid Email for " + input.Split(',')[1]);
        }

        return new Member(Convert.ToInt64(input.Split(',')[0]), input.Split(',')[1], input.Split(',')[2], input.Split(',')[3], input.Split(',')[4], input.Split(',')[5], input.Split(',')[6], input.Split(',')[7]);
    }

    public long Id {
        get { return _id; }
        set { _id = value; }
    }
    public string FirstName {
        get { return _firstName; }
        set { _firstName = value; }
    }
    public string LastName {
        get { return _lastName; }
        set { _lastName = value; }
    }
    public string Email {
        get { return _email; }
        set { _email = value; }
    }
    public string ContactNumber {
        get { return _contactNumber; }
        set { _contactNumber = value; }
    }
    public string LicenseNumber {
        get { return _licenseNumber; }
        set { _licenseNumber = value; }
    }
    public string LicenseStartDate {
        get { return _licenseStartDate; }
        set { _licenseStartDate = value; }
    }
    public string LicenseExpiryDate {
        get { return _licenseExpiryDate; }
        set { _licenseExpiryDate = value; }
    }

    public int CompareTo(object other) {
        return this.FirstName.CompareTo(((Member)other).FirstName);
    }
}