﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class PaymentUtil
{
    public double MakePayment(Dictionary<string, float> bankTax, string bankName, double amount)
    {
        try
        {
            amount += (bankTax[bankName] * amount) / 100;
        }
        catch (KeyNotFoundException)
        {
            Environment.Exit(0);
        }
     
        return amount;
    }

    public double MakePayment(double amount)
    {
        float serviceTax = 5.2f;
        float vat = 2.3f;
        amount += (amount * serviceTax) / 100;
        amount += (amount * vat) / 100;
        return amount;
    }

    public double MakePayment(double amount, float discountPercent)
    {
        amount -= (amount * discountPercent) / 100;
        return amount;
    }
}
