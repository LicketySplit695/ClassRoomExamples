using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

class Program
{
    static void Main(string[] args)
    {
        String id, name, email, contactNumber, createdOn, gender; 
        List<Customer> customerList = new List<Customer>();
        for (int i = 0; i < 2; i++)
        {

            Console.WriteLine("Customer" + (i + 1) + " :");
            Console.WriteLine("id:");
            id = Console.ReadLine();
            Console.WriteLine("name:");
            name = Console.ReadLine();
            Console.WriteLine("Gender:");
            gender = Console.ReadLine();
            Console.WriteLine("email:");
            email = Console.ReadLine();
            Console.WriteLine("contact number:");
            contactNumber = Console.ReadLine();
            Console.WriteLine("createdOn:");
            createdOn = Console.ReadLine();
            DateTime dt;
            DateTime.TryParse(createdOn,CultureInfo.InvariantCulture,DateTimeStyles.None,out dt);
            customerList.Add(new Customer(Convert.ToInt64(id),name,Convert.ToChar(gender),email,contactNumber,dt));

        }
        foreach (Customer i in customerList)
        {
            Console.WriteLine(i);
        }

        if (customerList[0].Equals(customerList[1]))
        {
            Console.WriteLine("Customer 1 is same as Customer 2");
        }
        else {
            Console.WriteLine("Customer 1 and Customer 2 are different");
        }
        Console.ReadLine();
    }
}