﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    class Customer
    {
        long _id;

        public long Id
        {
            get { return _id; }
            set { _id = value; }
        }

        string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        char _gender;

        public char Gender
        {
            get { return _gender; }
            set { _gender = value; }
        }

        string _email;

        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }

        string _contactNumber;

        public string ContactNumber
        {
            get { return _contactNumber; }
            set { _contactNumber = value; }
        }

        DateTime _createdOn;

        public DateTime CreatedOn
        {
            get { return _createdOn; }
            set { _createdOn = value; }
        }

        public Customer()
        { 
        }

        public Customer(long _id, string _name, char _gender, string _email, string _contactNumber, DateTime _createdOn)
        {
            Id = _id;
            Name = _name;
            Gender = _gender;
            Email = _email;
            ContactNumber = _contactNumber;
            CreatedOn = _createdOn;
        }

        public override string ToString()
        {
            return string.Format("Customer id: {0}\nCustomer: {1}\nCustomer contact details: {2}, {3}",Id,Name,ContactNumber,Email);
        }

        public override bool Equals(object obj)
        {
            if ((obj == null) || !(obj.GetType() == this.GetType()))
            {
                return false;
            }
            else 
            {
                Customer c = (Customer)obj;
                return this.Email.Equals(c.Email) && this.ContactNumber.Equals(c.ContactNumber);
            }
        }

        public override int GetHashCode()
        {
            return this.Email.GetHashCode() + this.ContactNumber.GetHashCode();
        }
    }

