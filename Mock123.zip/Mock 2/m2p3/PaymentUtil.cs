﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class PaymentUtil
{
    public double MakePayment(Dictionary<string, float> bankTax, string bankName, double amount)
    {  
        double total = 0f;
        total = amount + ((bankTax[bankName.ToUpper()] * amount) / 100);
        return total;
    }

    public double MakePayment(double amount)
    {
        float serviceTax = 5.2f;
        float vat = 2.3f;
        //fill code here.
        double total = 0f;
        double serv = ((serviceTax * amount) / 100);
  
        total = total + amount + serv;

        double vatv = ((vat * total) / 100);

        total = total + vatv;

        return total;
    }

    public double MakePayment(double amount, float discountPercent)
    {
        double total = 0f;
        //fill code here.
        double discount = 0f;

        discount = ((discountPercent * amount) / 100);
        total = total + amount - discount;

        return total;
    }
}
