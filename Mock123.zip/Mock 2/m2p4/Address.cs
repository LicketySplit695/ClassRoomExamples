﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//namespace Q4 {
    class Address {
        string _street, _city, _state, _country;
        int _zipCode;

        public Address() {}

        public Address(string _street, string _city, string _state, string _country, int _zipCode) {
            Street = _street;
            City = _city;
            State = _state;
            Country = _country;
            ZipCode = _zipCode;
        }

        public string Country {
            get { return _country; }
            set { _country = value; }
        }
        public string State {
            get { return _state; }
            set { _state = value; }
        }
        public string City {
            get { return _city; }
            set { _city = value; }
        }
        public string Street {
            get { return _street; }
            set { _street = value; }
        }
        public int ZipCode {
            get { return _zipCode; }
            set { _zipCode = value; }
        } 
    }
//}
