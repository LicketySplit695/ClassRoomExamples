﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//namespace Q4 {
    class Customer {
        long _id;

        public long Id {
            get { return _id; }
            set { _id = value; }
        }

        string _name;

        public string Name {
            get { return _name; }
            set { _name = value; }
        }

        char _gender;

        public char Gender {
            get { return _gender; }
            set { _gender = value; }
        }

        string _email;

        public string Email {
            get { return _email; }
            set { _email = value; }
        }

        string _contactNumber;

        public string ContactNumber {
            get { return _contactNumber; }
            set { _contactNumber = value; }
        }

        DateTime _createdOn;

        public DateTime CreatedOn {
            get { return _createdOn; }
            set { _createdOn = value; }
        }

        private Address _address;

        public Address Address {
            get { return _address; }
            set { _address = value; }
        }

        public Customer() {}

        public Customer(long _id, string _name, char _gender, string _email, string _contactNumber, DateTime _createdOn, Address _address) {
            Id = _id;
            Name = _name;
            Gender = _gender;
            Email = _email;
            ContactNumber = _contactNumber;
            CreatedOn = _createdOn;
            Address = _address;
        }

        public Customer FindCustomerById(List<Customer> customerList, long id) {
            foreach (var i in customerList) {
                if (i.Id == id) {
                    return i;
                }
            }

            return null;
        }

        public List<Customer> FindCustomerListByState(List<Customer> customerList, string state) {
            List<Customer> list = new List<Customer>();

            foreach (var i in customerList) {
                if (i.Address.State.Equals(state)) {
                    list.Add(i);
                }
            }

            return list;
        }

        public override string ToString() {
            return string.Format("{0,-15}{1,-20}{2,-15}{3,-15}{4}", Name, Email, Address.City, Address.Country, Address.ZipCode);
        }
    }
//}