﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

class Program
{
    static void Main(string[] args)
    {
        int choice = 1;
        do
        {
            Console.WriteLine("Menu");
            Console.WriteLine("1. Parse Name");
            Console.WriteLine("2. Valid Email");
            Console.WriteLine("3. Play Contact Number");
            Console.WriteLine("4. User Lifetime");
            Console.WriteLine("5. Exit");
            choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    Console.WriteLine("Enter name:");
                    //fill your code
                    string name = Console.ReadLine();
                    ParseName(name);
                    break;
                case 2:
                    Console.WriteLine("Enter E-mail id:");
                    string email = Console.ReadLine();
                    IsValidEmail(email);
                    //fill your code
                    break;
                case 3:
                    Console.WriteLine("Enter contact number:");
                    //fill your code
                    string phone = Console.ReadLine();
                    playContactNumber(phone);
                    break;
                case 4:
                    Console.WriteLine("Enter Created on date(dd-MM-yyyy HH:mm):");
                    //fill your code
                    string date = Console.ReadLine();
                    userLifeTime(date);
                    break;
            }

        } while (choice != 5);

    }
    public static void ParseName(string name)
    {
        //string pattern1 = "^[A-Za-z]{1,}[~`!@#$%^&*()_+-=<>.,:'?/]{1}[A_Za-z]{1,}[~`!@#$%^&*()_+-=<>.,:'?/]{1}[A-Za-z]{1,}$";
        //string pattern2 = "^[A-Za-z]{1,}[~`!@#$%^&*()_+-=<>.,:'?/]{1}[A_Za-z]{1,}$";
        //bool a = Regex.IsMatch(name,pattern1);
        //bool b = Regex.IsMatch(name, pattern2);
        //if (a)
        //{
        //    Regex pattern = new Regex("[^A-Za-z]");
        //    name = pattern.Replace(name, " ");
        //}
        //else if (b)
        //{
        Regex pattern = new Regex("[^A-Za-z]");
        name = pattern.Replace(name, " ");
        //}
        //else
        //{

        //}
        Console.WriteLine(name);
    }

    public static void userLifeTime(string time)
    {
        DateTime dateOld = DateTime.ParseExact("28-07-2017 09:00", "dd-MM-yyyy hh:mm", null);
        DateTime user = DateTime.ParseExact(time, "dd-MM-yyyy HH:mm", null);
        TimeSpan d = user - dateOld;
        double d1 = d.TotalMinutes;
        Console.WriteLine("Life time is: {0} minutes", d1);

    }

    public static void IsValidEmail(string email)
    {
        string pattern1 = "^[A-Z.a-z]{1,}[@]{1}[A-Za-z]{1,}[.]{1}[con]{1}[ore]{1}[mgt]{1}$";
        bool a = Regex.IsMatch(email, pattern1);
        if (a)
        {
            Console.WriteLine("Email id is valid");
        }
        else
        {
            Console.WriteLine("Email is invalid");
        }
    }

    public static void playContactNumber(string phone)
    {
        //fill your code
        string pattern = "^[0-9]{3}[-]{1}[0-9]{4}[-]{1}[0-9]{10}$";
        bool check = Regex.IsMatch(phone, pattern);
        if (check)
        {

            string[] s = phone.Split('-');
            //string a = s[2];
            int sum = 0;
            char[] c = s[2].ToCharArray();
            for (int i = 0; i < c.Length; i++)
            {
                sum = sum + (Convert.ToInt32(c[i].ToString()));
            }
            for (int j = 0; j < c.Length; j++)
            {
                if (sum >= 10)
                {
                    string r = Convert.ToString(sum);
                    sum = 0;
                    char[] c1 = r.ToCharArray();
                    for (int i = 0; i < c1.Length; i++)
                    {
                        sum = sum + (Convert.ToInt32(c1[i].ToString()));
                    }

                }
                else
                {
                    Console.WriteLine("Sum of contact number: {0}", sum);
                    break;
                }
            }
        }
        else
        {
            Console.WriteLine("Contact number invalid ");
        }

    }


    //public static void ConvertRegNum(string reg)
    //{
    //    reg = reg.ToUpper();
    //    Regex pattern = new Regex("[^a-zA-Z0-9]");
    //    reg = pattern.Replace(reg, "-");
    //    Console.WriteLine(reg);
    //}
}