using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        string name, email, contactNumber, createdOn;
        char gender;
        long id;
        List<Customer> customerList = new List<Customer>();
        for (int i = 0; i < 2; i++)
        {

            Console.WriteLine("Customer" + (i + 1) + " :");
            Console.WriteLine("id:");
            id = Convert.ToInt64(Console.ReadLine());
            Console.WriteLine("name:");
            name = Console.ReadLine();
            Console.WriteLine("Gender:");
            gender = Convert.ToChar(Console.ReadLine());
            Console.WriteLine("email:");
            email = Console.ReadLine();
            Console.WriteLine("contact number:");
            contactNumber = Console.ReadLine();
            Console.WriteLine("createdOn:");
            createdOn = Console.ReadLine();

            DateTime dt = DateTime.ParseExact(createdOn, "dd/MM/yyyy HH:mm:ss", null);

            customerList.Add(new Customer(id, name, gender, email, contactNumber, dt));
        }
        foreach (var i in customerList)
        {
            Console.WriteLine(i.ToString());
        }

        if (customerList[0].Equals(customerList[1]))
        {
            Console.WriteLine("Customer 1 is same as Customer 2");
        }
        else {
            Console.WriteLine("Customer 1 and Customer 2 are different");
        }
        Console.ReadLine();
    }
}