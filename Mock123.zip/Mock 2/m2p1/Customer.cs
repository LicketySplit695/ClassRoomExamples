﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Customer
{
    long _id;

    public long Id
    {
        get { return _id; }
        set { _id = value; }
    }
    string _name;

    public string Name
    {
        get { return _name; }
        set { _name = value; }
    }
    char _gender;

    public char Gender
    {
        get { return _gender; }
        set { _gender = value; }
    }
    string _email;

    public string Email
    {
        get { return _email; }
        set { _email = value; }
    }
    string _contactNumber;

    public string ContactNumber
    {
        get { return _contactNumber; }
        set { _contactNumber = value; }
    }
    DateTime _createdOn;

    public DateTime CreatedOn
    {
        get { return _createdOn; }
        set { _createdOn = value; }
    }

    internal Customer() { }

    internal Customer(long id, string name, char gender, string email, string contactNumber, DateTime createdOn)
    {
       Id = id;
       Name = name;
       Gender = gender;
       Email = email;
       ContactNumber = contactNumber;
       CreatedOn = createdOn;
    }

    public override string ToString()
    {
        return "Customer id: " +Id+ "\nCustomer: "+Name+ "\nCustomer contact details: "+ContactNumber+", "+ Email;
    }

    public override bool Equals(object obj)
    {
        return this.Email == ((Customer)obj).Email && this.ContactNumber == ((Customer)obj).ContactNumber;
    }

    public override int GetHashCode()
    {
        return Email.GetHashCode() + ContactNumber.GetHashCode();
    }
}

