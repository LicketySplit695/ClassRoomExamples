using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;

public class Booking {
    long _bookingId, _customerId, _carId;
    double _amount;
    string _paymentMode, _serviceEngineer;
    DateTime _dateTimeOfService;

    public Booking() {}

    public Booking(long _bookingId, DateTime _dateTimeOfService, string _paymentMode, long _customerId, long _carId, double _amount, string _serviceEngineer) {
        BookingId = _bookingId;
        DateTimeOfService = _dateTimeOfService;
        PaymentMode = _paymentMode;
        CustomerId = _customerId;
        CarId = _carId;
        Amount = _amount;
        ServiceEngineer = _serviceEngineer;
    }

    public DateTime DateTimeOfService {
      get { return _dateTimeOfService; }
      set { _dateTimeOfService = value; }
    }
    public string ServiceEngineer {
      get { return _serviceEngineer; }
      set { _serviceEngineer = value; }
    }
    public string PaymentMode {
      get { return _paymentMode; }
      set { _paymentMode = value; }
    }
    public double Amount {
      get { return _amount; }
      set { _amount = value; }
    }
    public long CarId {
      get { return _carId; }
      set { _carId = value; }
    }
    public long CustomerId {
      get { return _customerId; }
      set { _customerId = value; }
    }
    public long BookingId {
      get { return _bookingId; }
      set { _bookingId = value; }
    }

    //fill code here.

    public static SortedDictionary<string,List<Booking>> OrganizeBookings(List<Booking> bookingList) {
        SortedDictionary<string,List<Booking>> dick = new SortedDictionary<string,List<Booking>>();

        var s = from i in bookingList
                group i by i.ServiceEngineer;

        foreach (var iterator in s) {
            dick.Add(iterator.Key, iterator.ToList());
        }

        return dick;
        //fill code here.
    }

    public static List<string> FindBestServiceEngineer(SortedDictionary<string, List<Booking>> dick) {
        List<string> outputList = new List<string>();
        SortedDictionary<double, string> output = new SortedDictionary<double, string>();
        List<string> hell = new List<string>();

        int i = 0;
        foreach (var iterator in dick) {
            double amount = 0;

            foreach (var j in iterator.Value) {
                amount += j.Amount;
            }

            outputList.Add(iterator.Key + " - " + iterator.Value.Count);
            output.Add(amount, outputList[i++]);
        }

        for (i=0;i<output.Count;i++) {
            hell.Add(output.Values.ToList()[output.Count - i - 1]);
        }

        return hell;
        //fill code here.
    }
}