﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;

public class Program {
    public static void Main(string[] args) {
        List<Booking> li = new List<Booking>();

        do {
            Console.WriteLine("Enter a booking detail:");
            string[] s = Console.ReadLine().Split(',');
            long a = Convert.ToInt64(s[0]);
            DateTime b = DateTime.ParseExact(s[1], "dd-MM-yyyy", null);
            long c = Convert.ToInt64(s[3]);
            long d = Convert.ToInt64(s[4]);
            double e = Convert.ToDouble(s[5]);
            Booking ob = new Booking(a, b, s[2], c, d, e, s[6]);
            li.Add(ob);
            Console.WriteLine("Do you want to add another booking detail:");
        } while (Console.ReadLine().Equals("yes"));

        Console.WriteLine("Name - No of Booking");
        var ass = Booking.FindBestServiceEngineer(Booking.OrganizeBookings(li));

        foreach (var iterator in ass) {
            Console.WriteLine(iterator);
        }

        //fill code here.
    }
}
