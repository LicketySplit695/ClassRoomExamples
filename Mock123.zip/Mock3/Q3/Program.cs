﻿using System.Text.RegularExpressions;
using System;

public class Program {
    public static void Main(string[] args) {
        Console.WriteLine("Enter license number:");
        string licenseNumber = Console.ReadLine();
        
        Console.WriteLine("Menu:\n" +
                "1) Validate licence Number\n" +
                "2) Check Driver Experience");
        Console.WriteLine("Enter choice: ");
        int choice = Convert.ToInt32(Console.ReadLine());
        
        
        switch (choice) {
            case 1:
                if(ValidateLicenseNumber(licenseNumber)) {
                    Console.WriteLine("License number is valid");
                } else {
                    Console.WriteLine("License number is not valid");
                }
                break;
            case 2:
                if(IsExperiencedDriver(licenseNumber)) {
                    Console.WriteLine("Experienced Driver");
                } else {
                    Console.WriteLine("Not Experienced Driver");
                }
                break;
            default:
                Console.WriteLine("Invalid option");
                break;
        }
        
    }

    public static bool ValidateLicenseNumber(string licenceNumber) {
        DateTime currentDate= DateTime.ParseExact("28-11-2017", "dd-MM-yyyy", null);
        int currentYear = currentDate.Year;

        if (licenceNumber.Length != 15) {
            return false;
        }
        if (Convert.ToInt32(licenceNumber.Substring(2, 2)) < 10 || Convert.ToInt32(licenceNumber.Substring(2, 2)) > 50) {
            return false;
        }
        if (Convert.ToInt32(licenceNumber.Substring(4, 4)) < 2005 || Convert.ToInt32(licenceNumber.Substring(4, 4)) > 2016) {
            return false;
        }

        string pattern = "^[A-Z]{2}[0-9]{6}[1-9]{7}$";
        return Regex.IsMatch(licenceNumber, pattern);

        //fill code here.
    }
    
    public static bool IsExperiencedDriver(string licenceNumber) {
        DateTime currentDate= DateTime.ParseExact("28-11-2017", "dd-MM-yyyy", null);
        int currentYear = currentDate.Year;

        return currentYear - Convert.ToInt32(licenceNumber.Substring(4, 4)) >= 5;
        //fill code here.
    }
}
