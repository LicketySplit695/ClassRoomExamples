using System;
using System.Text.RegularExpressions;

public class Customer : IComparable<Customer> {
    long _customerId;
    string _firstName, _lastName, _gender, _email, _phoneNumber, _address;

    public Customer() {}

    public Customer(long _customerId, string _firstName, string _lastName, string _gender, string _email, string _phoneNumber, string _address) {
        CustomerId = _customerId;
        FirstName = _firstName;
        LastName = _lastName;
        Gender = _gender;
        Email = _email;
        PhoneNumber = _phoneNumber;
        Address = _address;
    }

    public long CustomerId {
        get { return _customerId; }
        set { _customerId = value; }
    }
    public string Address {
        get { return _address; }
        set { _address = value; }
    }
    public string PhoneNumber {
        get { return _phoneNumber; }
        set { _phoneNumber = value; }
    }
    public string Email {
        get { return _email; }
        set { _email = value; }
    }
    public string Gender {
        get { return _gender; }
        set { _gender = value; }
    }
    public string LastName {
        get { return _lastName; }
        set { _lastName = value; }
    }
    public string FirstName {
        get { return _firstName; }
        set { _firstName = value; }
    }

    public override string ToString() {
        return string.Format("{0}{1,25}{2,25}{3,25}{4,25}{5,25}", CustomerId, FirstName, LastName, Gender, Email, PhoneNumber);
    }

    public void ValidateEmail() {
        string pattern = "^[A-Za-z0-9]{1,}[@]{1}[A-Za-z0-9]{1,}[.]{1}[com | org]{3}$";
        if (!Regex.IsMatch(Email, pattern)) {
            throw new InvalidEmailException("Invalid Email for the user");
        }
    }

    public int CompareTo(Customer other) {
        return this.FirstName.CompareTo(other.FirstName);
    }
}
