﻿using System;
using System.Collections.Generic;
using System.Collections;

public class Program {
    public static void Main(string[] args) {
        List<Customer> customerList = new List<Customer>();
        string customerDetails;
        String choice;
        long _customerId;
        string _firstName, _lastName, _gender, _email, _phoneNumber, _address;

        Customer customerObject = null;

        do {
            Console.WriteLine("Enter customer details: ");
            customerDetails = Console.ReadLine();

            _customerId = Convert.ToInt64(customerDetails.Split(',')[0]);
            _firstName = customerDetails.Split(',')[1];
            _lastName = customerDetails.Split(',')[2];
            _gender = customerDetails.Split(',')[3];
            _email = customerDetails.Split(',')[4];
            _phoneNumber = customerDetails.Split(',')[5];
            _address = customerDetails.Split(',')[6];

            customerObject = new Customer(_customerId, _firstName, _lastName, _gender, _email, _phoneNumber, _address);

            //fill code here.
            try {
                customerObject.ValidateEmail();
                customerList.Add(customerObject);
            }
            catch (InvalidEmailException ex) {
                Console.WriteLine(ex.GetType() + ": " + ex.Message);
                //fill code here.
            }

            Console.WriteLine("Do you want to continue?");
            choice = Console.ReadLine();
        } while (choice.Equals("yes"));

        customerList.Sort();

        Console.WriteLine("{0}{1,25}{2,25}{3,25}{4,25}{5,25}", "Id", "First Name", "Last Name", "Gender", "Email", "Phone Number");

        foreach (var iterator in customerList) {
            Console.WriteLine(iterator);
        }

		//fill code here.
    }

}
