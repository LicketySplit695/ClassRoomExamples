using System;

public class Customer {
    long _customerId;
    string _firstName, _lastName, _gender, _email, _phoneNumber, _address;

    public Customer() {}

    public Customer(long _customerId, string _firstName, string _lastName, string _gender, string _email, string _phoneNumber, string _address) {
        CustomerId = _customerId;
        FirstName = _firstName;
        LastName = _lastName;
        Gender = _gender;
        Email = _email;
        PhoneNumber = _phoneNumber;
        Address = _address;
    }

    public long CustomerId {
        get { return _customerId; }
        set { _customerId = value; }
    }
    public string Address {
        get { return _address; }
        set { _address = value; }
    }
    public string PhoneNumber {
        get { return _phoneNumber; }
        set { _phoneNumber = value; }
    }
    public string Email {
        get { return _email; }
        set { _email = value; }
    }
    public string Gender {
        get { return _gender; }
        set { _gender = value; }
    }
    public string LastName {
        get { return _lastName; }
        set { _lastName = value; }
    }
    public string FirstName {
        get { return _firstName; }
        set { _firstName = value; }
    }

    public override string ToString() {
        return string.Format("Customer:{0},{1}\nContact details:{2},{3},{4}", FirstName, LastName, PhoneNumber, Email, Address);
    }

    public override bool Equals(object obj) {
        if (obj == null) {
            return false;
        }
        if (obj.GetType() != this.GetType()) {
            return false;
        }

        return this.FirstName.Equals(((Customer)obj).FirstName) && this.LastName.Equals(((Customer)obj).LastName) && this.Email.Equals(((Customer)obj).Email) && this.PhoneNumber.Equals(((Customer)obj).PhoneNumber);
    }

    public override int GetHashCode() {
        return this.FirstName.GetHashCode() + this.LastName.GetHashCode() + this.Email.GetHashCode() + this.PhoneNumber.GetHashCode();
    }
}
