using System;
using System.Collections;
using System.Collections.Generic;

public class Program {

    
    public static void Main(string[] args) 
    {
         
        List<Car> carList = new List<Car>();        
        while(true)
        {
          string menu = "Menu:\n1) Add a Car\n" +"2) Find a Car\n" +"3) Find CarList\n" +"4) Exit";
          Console.WriteLine(menu);
             int option = Convert.ToInt32(Console.ReadLine());
             if (option == 1)
             {
                 //fill code here.
                 carList.Add(Car.AddCar());
             }
		    if(option == 2) 
            {
                Console.WriteLine("Licence Number");
		        string licNo = Console.ReadLine();            
		        //fill code here.
                Car newCar = Car.FindCar(licNo, carList);
                if(newCar!=null)
                    Console.WriteLine(newCar);
                else
                    Console.WriteLine("Licence Number not present");
		    }
		    if(option == 3) 
            {
		       Console.WriteLine("Model");
		        string model = Console.ReadLine(); 
                        //fill code here.
                List<Car> newCarList=Car.FindCarList(model, carList);
                if (newCarList.Count == 0)
                {
                    Console.WriteLine("Car {0} not found", model);
                }
                else
                {
                    foreach (Car i in newCarList)
                    {
                        Console.WriteLine(i);
                    }
                }
		    }
		    if(option == 4) 
            {
		        break;
		    }
           
        }
    }
}
