using System;
using System.Collections.Generic;
  
public class Car {

	//fill code here.
    string _licenceNumber;
    public string LicenceNumber
    {
        get { return _licenceNumber; }
        set { _licenceNumber = value; }
    }

    string _model;
    public string Model
    {
        get { return _model; }
        set { _model = value; }
    }

    double _currentMileage;
    public double CurrentMileage
    {
        get { return _currentMileage; }
        set { _currentMileage = value; }
    }

    int _engineSize;
    public int EngineSize
    {
        get { return _engineSize; }
        set { _engineSize = value; }
    }

    private Car()
    { 
    }

    private Car(string _licenceNumber, string _model, double _currentMileage, int _engineSize)
    {
        LicenceNumber = _licenceNumber;
        Model = _model;
        CurrentMileage=_currentMileage;
        EngineSize=_engineSize;
    }
   
    public override string ToString()
    {
        return string.Format("Licence Number:{0}\nModel:{1}",LicenceNumber,Model);
    }


     public static Car AddCar() {
        
        String licenceNumber, model;Double currentMileage;int engineSize;
        Car c = null;
                  Console.WriteLine("Licence Number:");
            licenceNumber = Console.ReadLine();
            Console.WriteLine("Model:");
            model = Console.ReadLine();
            Console.WriteLine("Current Mileage:");
            currentMileage = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Engine Size:");
            engineSize = Convert.ToInt32(Console.ReadLine());
            c = new Car(licenceNumber,model,currentMileage,engineSize);
            return c;
        
    }
     public static Car FindCar(String licNo, List<Car> carList) {
        //fill code here.
         foreach (Car i in carList)
         {
             if (i.LicenceNumber.Equals(licNo))
                 return i;
         }
         return null;
      }
      public static List<Car> FindCarList(string model, List<Car> carList) {
        //fill code here.
          List<Car> newCraList = new List<Car>();
          foreach (Car i in carList)
          {
              if (i.Model.Equals(model))
              {
                  newCraList.Add(i);
              }
          }
          return newCraList;
      }


}
