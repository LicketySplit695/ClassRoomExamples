using System;

public class CreditCardPayment:PaymentMode {
    string _creditcardNumber;

    public string CreditcardNumber
    {
        get { return _creditcardNumber; }
        set { _creditcardNumber = value; }
    }
    string _holderName;

    public string HolderName
    {
        get { return _holderName; }
        set { _holderName = value; }
    }
    string _cardNumber;

    public string CardNumber
    {
        get { return _cardNumber; }
        set { _cardNumber = value; }
    }
    DateTime _dateOfExpiry;

    public DateTime DateOfExpiry
    {
        get { return _dateOfExpiry; }
        set { _dateOfExpiry = value; }
    }

    public CreditCardPayment(string _creditcardNumber, string _holderName, string _cardNumber, DateTime _dateOfExpiry, string _type)
        : base(_type)
    {
        CreditcardNumber = _creditcardNumber;
        HolderName = _holderName;
        CardNumber = _cardNumber;
        DateOfExpiry = _dateOfExpiry;
    }

    public override double MakePayment(Booking booking)
    {
        double amount = booking.Amount * 1.02;
        return amount;
    }
}

