using System;
using System.Collections.Generic;
  
public class Car {

    string _licenceNumber;
    public string LicenceNumber
    {
        get { return _licenceNumber; }
        set { _licenceNumber = value; }
    }

    public Car()
    { 
    }

    public Car(string _licenceNumber)
    {
        LicenceNumber = _licenceNumber;
    }


     public static Car AddCar() {

         String licenceNumber;
         Car c = null;
            Console.WriteLine("Licence Number:");
            licenceNumber = Console.ReadLine();
            c = new Car(licenceNumber);
            return c;
        
    }
     public static Car FindCar(String licNo, List<Car> carList) {
         foreach (Car i in carList)
         {
             if (i.LicenceNumber.Equals(licNo))
                 return i;
         }
         return null;
      }
}
