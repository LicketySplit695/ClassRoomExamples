using System;

public class Customer {
    long _customerId;

    public Customer() {}

    public Customer(long _customerId) 
    {
        CustomerId = _customerId;
    }

    public long CustomerId
    {
        get { return _customerId; }
        set { _customerId = value; }
    }
}
