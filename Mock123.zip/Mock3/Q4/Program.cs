using System;
using System.Globalization;

public class Program {
    public static void Main(string[] args) 
    {
        long bookingId;
        string dateTimeOfService;
        string paymentMode;
        string creditcardNumber;
        string holderName;
        string walletNumber;
        string cardNumber;
        string serviceEngineer;
        string dateOfExpiry;
        double amount;
        Customer customer = new Customer();
        Car car = new Car();
        
        Console.WriteLine("bookingId");
        bookingId = Convert.ToInt64(Console.ReadLine());
        
        Console.WriteLine("dateTimeOfService");
        dateTimeOfService = Console.ReadLine();
        
        Console.WriteLine("paymentMode");
        paymentMode = Console.ReadLine();
        
        Console.WriteLine("customer id");
        customer.CustomerId= Convert.ToInt64(Console.ReadLine());
        
        Console.WriteLine("licence number");
        car.LicenceNumber= Console.ReadLine();
        
        Console.WriteLine("amount");
        amount = Convert.ToDouble(Console.ReadLine());
        
        Console.WriteLine("service engineer");
        serviceEngineer = Console.ReadLine();
        
        Booking booking = new Booking(bookingId,dateTimeOfService,paymentMode,customer,car,amount,serviceEngineer);
        
        PaymentMode paymentModeIns = null;
        
        switch (booking.PaymentMode) {
            case "creditcardpayment":
                Console.WriteLine("creditcard number");
                creditcardNumber = Console.ReadLine();
                Console.WriteLine("holder name");
                holderName = Console.ReadLine();
                Console.WriteLine("card number");
                cardNumber = Console.ReadLine();
                Console.WriteLine("date of expiry");
                dateOfExpiry = Console.ReadLine();
                DateTime dt;
                DateTime.TryParse(dateOfExpiry,CultureInfo.InvariantCulture,DateTimeStyles.None, out dt);
                paymentModeIns = new CreditCardPayment(creditcardNumber, holderName, cardNumber, dt, booking.PaymentMode);
                break;

            case "walletpayment":
                Console.WriteLine("wallet number");
                walletNumber = Console.ReadLine();
                paymentModeIns = new WalletPayment(walletNumber, booking.PaymentMode);
                break;
        }

        Console.WriteLine("Cost is Rs "+Math.Round(paymentModeIns.MakePayment(booking)));
    }
}
