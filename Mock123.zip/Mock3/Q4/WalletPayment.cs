using System;  
class WalletPayment : PaymentMode
{
    string _walletNumber;

    public string WalletNumber
    {
        get { return _walletNumber; }
        set { _walletNumber = value; }
    }

    public WalletPayment(string _walletNumber, string _type)
        : base(_type)
    {
        WalletNumber = _walletNumber;
    }

    public override double MakePayment(Booking booking)
    {
        double amount = booking.Amount * 0.95;
        return amount;
    }

}
