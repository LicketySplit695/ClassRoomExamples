using System;

abstract public class PaymentMode 
{
    string _type;

    public string Type
    {
        get { return _type; }
        set { _type = value; }
    }
    public PaymentMode(string _type)
    {
        Type = _type;
    }

    public abstract double MakePayment(Booking booking);
}
