using System;
public class Booking 
{
    long _bookingId;
    public long BookingId
    {
        get { return _bookingId; }
        set { _bookingId = value; }
    }

    DateTime _dateTimeOfService;
    public DateTime DateTimeOfService
    {
        get { return _dateTimeOfService; }
        set { _dateTimeOfService = value; }
    }

    string _paymentMode;
    public string PaymentMode
    {
        get { return _paymentMode; }
        set { _paymentMode = value; }
    }

    Customer _customerIns;
    public Customer CustomerIns
    {
        get { return _customerIns; }
        set { _customerIns = value; }
    }

    Car _carIns;
    public Car CarIns
    {
        get { return _carIns; }
        set { _carIns = value; }
    }

    double _amount;
    public double Amount
    {
        get { return _amount; }
        set { _amount = value; }
    }

    string _serviceEngineer;
    public string ServiceEngineer
    {
        get { return _serviceEngineer; }
        set { _serviceEngineer = value; }
    }

    public Booking()
    { }

    public Booking(long bookingId,string dateTimeOfService,string paymentMode,Customer customer,Car car,double amount,string serviceEngineer)
    {
        BookingId = bookingId;
        DateTime dt;
        DateTime.TryParse(dateTimeOfService,System.Globalization.CultureInfo.InvariantCulture,System.Globalization.DateTimeStyles.None,out dt);
        DateTimeOfService = dt;
        PaymentMode = paymentMode;
        CustomerIns = customer;
        CarIns = car;
        Amount = amount;
        ServiceEngineer = serviceEngineer;
    }
}

